<?php
/**
 * Plugin Name: 全国お医者さんマップ
 * Description: 横浜市青葉区・緑区の病院・クリニックを地図・駅・診療科から探せるサイト一式。有効化すると必要なページ（駅別・診療科別・休日夜間・このサイトについて）を自動で作ります。
 * Version: 2.43.1
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Update URI: https://github.com/shibainugen/isha-map
 * License: GPLv2 or later
 * Text Domain: aoba-isha-map
 */

if (!defined('ABSPATH')) exit;

define('AOBA_ISHA_MAP_VER', '2.43.1');
define('AOBA_ISHA_MAP_FILE', __FILE__);
define('AOBA_ISHA_MAP_DIR', plugin_dir_path(__FILE__));

require_once AOBA_ISHA_MAP_DIR . 'includes/data.php';
require_once AOBA_ISHA_MAP_DIR . 'includes/render.php';
require_once AOBA_ISHA_MAP_DIR . 'includes/pages.php';
require_once AOBA_ISHA_MAP_DIR . 'includes/design.php';
require_once AOBA_ISHA_MAP_DIR . 'includes/updater.php';
require_once AOBA_ISHA_MAP_DIR . 'includes/clinic.php';
require_once AOBA_ISHA_MAP_DIR . 'includes/virtual.php';

// ブロックテーマでは本文が wp_enqueue_scripts より先に描画されるため、init で登録しておく
add_action('init', function () {
	$u = plugin_dir_url(__FILE__);
	wp_register_style('leaflet', 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css', array(), '1.9.4');
	wp_register_script('leaflet', 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js', array(), '1.9.4', true);
	// スマホで1本指はページのスクロール、2本指で地図を動かす（MIT: elmarquis/Leaflet.GestureHandling 1.2.2）
	wp_register_style('leaflet-gesture', $u . 'assets/vendor/leaflet-gesture-handling.min.css', array('leaflet'), '1.2.2');
	wp_register_script('leaflet-gesture', $u . 'assets/vendor/leaflet-gesture-handling.min.js', array('leaflet'), '1.2.2', true);
	wp_register_style('aoba-isha-map', $u . 'assets/map.css', array('leaflet', 'leaflet-gesture'), AOBA_ISHA_MAP_VER);
	wp_register_style('aoba-isha-pages', $u . 'assets/pages.css', array(), AOBA_ISHA_MAP_VER);
	wp_register_script('aoba-isha-map', $u . 'assets/map.js', array('leaflet', 'leaflet-gesture'), AOBA_ISHA_MAP_VER, true);
	wp_register_script('aoba-isha-navi', $u . 'assets/navi.js', array(), AOBA_ISHA_MAP_VER, true);
});

/** [aoba_isha_map station="aobadai" dept="shonika"] 地図と近い順リスト */
add_shortcode('aoba_isha_map', function ($atts) {
	$a = shortcode_atts(array('station' => '', 'dept' => '', 'area' => ''), $atts);
	wp_enqueue_style('aoba-isha-map');
	wp_enqueue_script('aoba-isha-map');
	static $done = false;
	if ($done) return ''; // 1ページに地図は1つだけ
	$done = true;
	$preset = call_user_func(function () use ($a) { // 分割データで軽いので、覚えておかずに毎回作る
		$preset = array();
		$st = aim_station($a['station']);
		if ($st) $preset['origin'] = array('lat' => $st['lat'], 'lng' => $st['lng'], 'label' => $st['name'] . '駅');
		$defs = aim_area_defs();
		if (!$st && $a['area'] && isset($defs[$a['area']])) {
			$c = aim_area_center($a['area']);
			if ($c) $preset['origin'] = array('lat' => $c[0], 'lng' => $c[1], 'label' => aim_area_name($a['area']) . 'の中心');
		}
		$dg = aim_dept_group($a['dept']);
		if ($dg) $preset['group'] = array('slug' => $dg['slug'], 'label' => $dg['label']);
		return $preset;
	});
	$d = aim_meta();
	wp_add_inline_script('aoba-isha-map', 'window.AOBA_ISHA_MAP = ' . wp_json_encode(array(
		'tiles' => aim_map_areas(),
		'total' => $d['total'],
		'asof' => isset($d['asof']) ? $d['asof'] : '',
		'telAsof' => isset($d['telAsof']) ? $d['telAsof'] : '',
		'preset' => $preset,
		'groups' => aim_dept_groups_js(),
		'hidden' => array_keys(aim_hidden_map()),
	)) . ';', 'before');
	ob_start();
	include AOBA_ISHA_MAP_DIR . 'templates/map.php';
	return ob_get_clean();
});

/** [aoba_isha_list station="aobadai" dept="shonika"] 検索エンジンにも読める医療機関一覧 */
add_shortcode('aoba_isha_list', function ($atts) {
	$a = shortcode_atts(array('station' => '', 'dept' => '', 'area' => ''), $atts);
	wp_enqueue_style('aoba-isha-pages');
	return aim_render_list($a['station'], $a['dept'], $a['area']);
});

/** [aoba_isha_index type="station|dept"] 駅・診療科へのリンク一覧 */
add_shortcode('aoba_isha_index', function ($atts) {
	$a = shortcode_atts(array('type' => 'station', 'dept' => ''), $atts);
	wp_enqueue_style('aoba-isha-pages');
	return aim_render_index($a['type'], $a['dept']);
});

/** [aoba_isha_emergency] 休日・夜間の受診案内 */
add_shortcode('aoba_isha_emergency', function () {
	wp_enqueue_style('aoba-isha-pages');
	return aim_cache('emergency', function () {
		ob_start();
		include AOBA_ISHA_MAP_DIR . 'templates/emergency.php';
		return ob_get_clean();
	});
});

/** [aoba_isha_about] このサイトについて */
add_shortcode('aoba_isha_about', function () {
	wp_enqueue_style('aoba-isha-pages');
	ob_start();
	include AOBA_ISHA_MAP_DIR . 'templates/about.php';
	return ob_get_clean();
});

/** [aoba_isha_privacy] プライバシーポリシー */
add_shortcode('aoba_isha_privacy', function () {
	wp_enqueue_style('aoba-isha-pages');
	ob_start();
	include AOBA_ISHA_MAP_DIR . 'templates/privacy.php';
	return ob_get_clean();
});

/** [aoba_isha_links] トップに置く「駅・診療科・休日夜間」への入口 */
add_shortcode('aoba_isha_links', function () {
	wp_enqueue_style('aoba-isha-pages');
	return aim_render_links();
});

// 掲載が少ないページは noindex（ページは残す・リンクはたどってもらう）
add_filter('wp_robots', function ($robots) {
	if (is_singular('page') && get_post_meta(get_queried_object_id(), '_aim_noindex', true)) {
		$robots['noindex'] = true;
		$robots['follow'] = true;
		unset($robots['index']);
	}
	return $robots;
}, 99);
// サイトマップからも外す
add_filter('wp_sitemaps_posts_query_args', function ($args, $post_type) {
	if ($post_type !== 'page') return $args;
	$mq = isset($args['meta_query']) ? $args['meta_query'] : array();
	$mq[] = array('key' => '_aim_noindex', 'compare' => 'NOT EXISTS');
	$args['meta_query'] = $mq;
	return $args;
}, 10, 2);

// 入れ物ページ（_aim_noindex）を REST の一覧・個別から外す（未ログイン時）
add_filter('rest_page_query', function ($args, $request) {
	$mq = isset($args['meta_query']) ? $args['meta_query'] : array();
	$mq[] = array('key' => '_aim_noindex', 'compare' => 'NOT EXISTS');
	$args['meta_query'] = $mq;
	return $args;
}, 10, 2);
add_filter('rest_prepare_page', function ($response, $post, $request) {
	if (is_user_logged_in()) return $response;
	if (get_post_meta($post->ID, '_aim_noindex', true)) {
		return new WP_Error('rest_post_invalid_id', __('Invalid post ID.'), array('status' => 404));
	}
	return $response;
}, 10, 3);

// robots.txt で入れ物の直 URL だけ拒否する（公開ページの /eki/{駅}/ や /ka/{科}/{市区}/ は拒否しない）
add_filter('robots_txt', function ($output, $public) {
	if (!$public) return $output;
	$output .= "Disallow: /eki/aim-st/\n";
	$output .= "Disallow: /*/aim-area/\n";
	return $output;
}, 20, 2);

// 自動で作ったページには meta description を出す
add_action('wp_head', function () {
	if (!is_singular('page')) return;
	$desc = get_post_meta(get_the_ID(), '_aim_description', true);
	if ($desc) echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
}, 1);

/** 症状ナビの、JavaScript なしでも読める案内（クイズと同じ症状区分・同じ科へのリンク。診断はしない） */
function aim_navi_static_html() {
	$groups = array();
	foreach (aim_dept_groups() as $g) $groups[$g['slug']] = $g['label'];
	$link = function ($slugs) use ($groups) {
		$out = array();
		foreach ($slugs as $s) {
			if (empty($groups[$s])) continue;
			$u = aim_page_url('ka_' . $s);
			$out[] = $u ? '<a href="' . esc_url($u) . '">' . esc_html($groups[$s]) . '</a>' : esc_html($groups[$s]);
		}
		return implode('、', $out);
	};
	$adult = array(
		array('熱・かぜっぽい（せき・のど・鼻水）', array('naika', 'jibika', 'kokyuki')),
		array('頭が痛い', array('noshinkei', 'naika')),
		array('めまい・ふらつき', array('jibika', 'naika', 'junkanki')),
		array('胸の痛み・動悸・息切れ', array('junkanki', 'kokyuki', 'naika', 'seikei')),
		array('おなかが痛い・下痢・吐き気', array('shokaki', 'naika', 'fujinka', 'hinyokika')),
		array('皮膚（発疹・かゆみ・できもの）', array('hifuka', 'keisei', 'allergy')),
		array('けが・やけど・骨や関節・腰の痛み', array('seikei', 'keisei', 'hifuka', 'rheumatism')),
		array('目', array('ganka')),
		array('耳・鼻・のど', array('jibika', 'allergy', 'naika')),
		array('おしっこの悩み', array('hinyokika', 'naika')),
		array('生理・妊娠・女性の体', array('fujinka')),
		array('心の不調・眠れない', array('shinryonaika')),
		array('健康診断で引っかかった（血圧・血糖・コレステロールなど）', array('tonyobyo', 'junkanki', 'naika')),
	);
	$child = array(
		array('熱がある', array('shonika', 'jibika')),
		array('せき・ゼーゼーする', array('shonika')),
		array('おなかが痛い・吐く・下痢', array('shonika')),
		array('発疹・皮膚のトラブル', array('shonika', 'hifuka')),
		array('けが・やけど・誤飲', array('seikei', 'keisei', 'hifuka')),
		array('目・耳・鼻', array('ganka', 'jibika', 'shonika')),
	);
	$li = function ($rows) use ($link) {
		$h = '<ul class="ain-static-list">';
		foreach ($rows as $r) $h .= '<li><span class="ain-static-q">' . esc_html($r[0]) . '</span> → ' . $link($r[1]) . '</li>';
		return $h . '</ul>';
	};
	$er = aim_page_url('emergency');
	$h = '<div class="ain-static">';
	$h .= '<h2 class="ain-static-h">症状から診療科を探す（一覧）</h2>';
	$h .= '<p>上の案内は質問に答えながら科を絞ります。下の一覧は、よくある症状から案内している診療科へのリンクです。これは病気を診断するものではなく、受診する科の目安です。</p>';
	$h .= '<h3 class="ain-static-h3">大人（中学生以上）</h3>' . $li($adult);
	$h .= '<h3 class="ain-static-h3">子ども（小学生以下）</h3>' . $li($child);
	$h .= '<p class="ain-small">判断に迷うときや症状が重いときは、#7119（大人）・#8000（子ども）に相談するか、119番に電話してください。';
	if ($er) $h .= '休日・夜間の受診先は <a href="' . esc_url($er) . '">休日・夜間の受診案内</a> にまとめています。';
	$h .= '</p></div>';
	return $h;
}

/** [aoba_isha_navi] 症状から科を案内するナビ */
add_shortcode('aoba_isha_navi', function () {
	wp_enqueue_style('aoba-isha-pages');
	wp_enqueue_script('aoba-isha-navi');
	static $done = false;
	if ($done) return '';
	$done = true;
	$pages = array();
	foreach (aim_dept_groups() as $g) $pages[$g['slug']] = aim_page_url('ka_' . $g['slug']);
	$consult = json_decode((string) @file_get_contents(AOBA_ISHA_MAP_DIR . 'assets/consult.json'), true);
	wp_add_inline_script('aoba-isha-navi', 'window.AOBA_ISHA_NAVI = ' . wp_json_encode(array('pages' => $pages, 'emergency' => aim_page_url('emergency'), 'consult' => is_array($consult) ? $consult : array())) . ';', 'before');
	ob_start();
	include AOBA_ISHA_MAP_DIR . 'templates/navi.php';
	$html = ob_get_clean();
	return $html . aim_navi_static_html();
});

register_activation_hook(__FILE__, 'aim_create_pages');

// プラグインを上書き更新したら、ページの作成・更新を仕事として登録し、管理画面を開くたびに少しずつ進める
add_action('admin_init', function () {
	if (get_option('aim_ver') !== AOBA_ISHA_MAP_VER) {
		aim_create_pages(true);
		if (in_array(get_option('blogname'), array('青葉区お医者さんマップ', '首都圏お医者さんマップ', '全国お医者さんマップ'), true)) update_option('blogname', '全国お医者さんマップ');
		update_option('aim_ver', AOBA_ISHA_MAP_VER);
	}
	aim_run_page_job(20);
});
