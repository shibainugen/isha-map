<?php
if (!defined('ABSPATH')) exit;

function aim_sc_block($sc) {
	return "<!-- wp:shortcode -->\n" . $sc . "\n<!-- /wp:shortcode -->";
}

function aim_p_block($text) {
	return "<!-- wp:paragraph -->\n<p>" . $text . "</p>\n<!-- /wp:paragraph -->";
}

/**
 * ページを1つ用意する。無ければ作る。
 * $sync が true のときは、既にあるページのタイトル・本文・説明文もプラグインの内容に合わせる。
 */
function aim_ensure_page($key, $args, &$ids, $sync = false) {
	if (!empty($ids[$key])) {
		$p = get_post($ids[$key]);
		if ($p && $p->post_status !== 'trash') {
			if ($sync) {
				if ($p->post_title !== $args['title'] || $p->post_content !== $args['content'] || $p->post_status !== 'publish') {
					wp_update_post(array('ID' => $p->ID, 'post_title' => $args['title'], 'post_content' => $args['content'], 'post_status' => 'publish'));
				}
				if (!empty($args['desc'])) update_post_meta($p->ID, '_aim_description', $args['desc']);
				aim_set_noindex($p->ID, $args);
			}
			return $ids[$key];
		}
	}
	$id = wp_insert_post(array(
		'post_type' => 'page',
		'post_status' => 'publish',
		'post_title' => $args['title'],
		'post_name' => $args['slug'],
		'post_content' => $args['content'],
		'post_parent' => isset($args['parent']) ? $args['parent'] : 0,
		'menu_order' => isset($args['order']) ? $args['order'] : 0,
		'comment_status' => 'closed',
	));
	if ($id && !is_wp_error($id)) {
		$ids[$key] = $id;
		if (!empty($args['desc'])) update_post_meta($id, '_aim_description', $args['desc']);
		aim_set_noindex($id, $args);
	}
	return $ids[$key] ?? 0;
}

/** 掲載が少ない（3件以下）ページは検索に載せない印をつける */
function aim_set_noindex($id, $args) {
	if (!empty($args['noindex'])) update_post_meta($id, '_aim_noindex', 1);
	else delete_post_meta($id, '_aim_noindex');
}

function aim_contact_blocks() {
	return "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">運営者・お問い合わせ</h2>\n<!-- /wp:heading -->\n\n"
		. "<!-- wp:paragraph -->\n<p>運営：REグループ<br>メール：<a href=\"mailto:isha@re-kaitori.jp\">isha@re-kaitori.jp</a></p>\n<!-- /wp:paragraph -->\n\n"
		. aim_p_block('掲載内容の誤り・変更（診療時間、電話番号、休診・閉院など）のご連絡は、医療機関名を添えて上記メールアドレスまでお送りください。確認のうえ修正します。なお、病気や症状についてのご相談にはお答えできません。');
}

function aim_page_specs() {
	$specs = array();
	$area = aim_area_label();
	$total = aim_meta()['total'];

	$specs[] = array('key' => 'top', 'args' => array(
		'title' => '全国お医者さんマップ',
		'slug' => 'map',
		'order' => 1,
		'desc' => $area . 'の病院・クリニック' . $total . '件を地図で探せます。現在地や駅から近い順、診療科、いま診療時間内かどうか（目安）で絞り込み。休日・夜間の受診先も案内しています。',
		'content' => aim_sc_block('[aoba_isha_hero]') . "\n\n" . aim_sc_block('[aoba_isha_map]') . "\n\n" . aim_sc_block('[aoba_isha_links]'),
	));

	$specs[] = array('key' => 'eki', 'args' => array(
		'title' => '駅から探す',
		'slug' => 'eki',
		'order' => 2,
		'desc' => $area . 'の病院・クリニックを、たまプラーザ・青葉台・長津田・中山・町田・鶴川など最寄り駅ごとに探せます。',
		'content' => aim_p_block(aim_area_label() . 'の駅ごとに、最寄り駅がその駅になる病院・クリニックをまとめています。都県の名前を押すと駅の一覧が開きます。') . "\n\n" . aim_sc_block('[aoba_isha_index type="station"]'),
	));

	$defs = aim_area_defs();
	$cnt = aim_counts();
	// 駅ごとのページは入れ物1枚（/eki/{駅}/ で中身が変わる。virtual.php）
	$specs[] = array('key' => 'eki_host', 'parent_key' => 'eki', 'always_sync' => true, 'args' => array(
		'title' => AIM_VHOST_ST,
		'slug' => AIM_VHOST_ST_SLUG,
		'order' => 0,
		'noindex' => true,
		'content' => aim_sc_block('[aoba_isha_vpage]'),
	));

	$specs[] = array('key' => 'ka', 'args' => array(
		'title' => '診療科から探す',
		'slug' => 'ka',
		'order' => 3,
		'desc' => $area . 'の病院・クリニックを、内科・小児科・皮膚科・耳鼻咽喉科など診療科ごとに探せます。',
		'content' => aim_p_block('診療科ごとに、' . aim_area_label() . 'で診療している病院・クリニックをまとめています。関連する科（たとえば皮膚科なら小児皮膚科）も含めています。') . "\n\n" . aim_sc_block('[aoba_isha_index type="dept"]'),
	));

	foreach (aim_dept_groups() as $i => $g) {
		$n = isset($cnt['dept'][$g['slug']]) ? $cnt['dept'][$g['slug']] : 0;
		if (!$n) continue;
		$specs[] = array('key' => 'ka_' . $g['slug'], 'parent_key' => 'ka', 'args' => array(
			'title' => $g['label'] . 'の病院・クリニック',
			'slug' => $g['slug'],
			'order' => $i,
			'desc' => $area . 'で' . $g['label'] . 'を診療している病院・クリニック' . $n . '件を、市区ごと・最寄り駅ごとに掲載。診療時間・電話番号・いま診療時間内かどうか（目安）がわかります。',
			'content' => aim_p_block($area . 'で' . $g['label'] . 'を診療している病院・クリニック' . $n . '件を載せています。' . $g['note'] . '地図では現在地から近い順に並べ替えられます。下の市区を選ぶと、その市区の' . $g['label'] . 'を最寄り駅ごとに一覧できます。')
				. "\n\n" . aim_sc_block('[aoba_isha_map dept="' . $g['slug'] . '"]') . "\n\n" . aim_sc_block('[aoba_isha_index type="dept_areas" dept="' . $g['slug'] . '"]'),
		));
		// 市区町村ごとのページは科ごとに入れ物1枚（/ka/{科}/{市区町村}/ で中身が変わる。virtual.php）
		$specs[] = array('key' => 'ka_' . $g['slug'] . '_host', 'parent_key' => 'ka_' . $g['slug'], 'always_sync' => true, 'args' => array(
			'title' => AIM_VHOST_KD,
			'slug' => AIM_VHOST_KD_SLUG,
			'order' => 0,
			'noindex' => true,
			'content' => aim_sc_block('[aoba_isha_vpage]'),
		));

	}

	$specs[] = array('key' => 'navi', 'args' => array(
		'title' => '症状から何科か調べる',
		'slug' => 'shojo',
		'order' => 2,
		'desc' => '頭痛・腹痛・発熱・発疹など、症状から何科にかかればよいかの目安がわかります。' . $area . 'でその科を診療している病院・クリニックの一覧にそのまま進めます。',
		'content' => aim_p_block('いくつかの質問に答えると、何科にかかればよいかの目安をご案内します。急いだほうがよいサインがあるときは、119番や救急相談の電話番号をお知らせします。') . "\n\n" . aim_sc_block('[aoba_isha_navi]'),
	));

	$specs[] = array('key' => 'emergency', 'args' => array(
		'title' => '休日・夜間に具合が悪くなったら',
		'slug' => 'kyujitsu-yakan',
		'order' => 4,
		'desc' => $area . 'で休日・夜間に急に具合が悪くなったときの受診先。休日急患診療所、夜間急病センター、救急相談#7119、小児救急#8000をまとめています。',
		'content' => aim_sc_block('[aoba_isha_emergency]'),
	));

	$specs[] = array('key' => 'about', 'args' => array(
		'title' => 'このサイトについて',
		'slug' => 'about',
		'order' => 9,
		'desc' => '全国お医者さんマップのデータの出典と、ご利用にあたっての注意です。',
		'content' => aim_sc_block('[aoba_isha_about]') . "\n\n" . aim_contact_blocks(),
	));

	// 医療機関ごとのページの入れ物（/clinic/{id}/ で中身が変わる。入れ物自体は検索に載せない）
	$specs[] = array('key' => 'clinic', 'always_sync' => true, 'args' => array(
		'title' => AIM_CLINIC_HOST_TITLE,
		'slug' => 'clinic',
		'order' => 20,
		'noindex' => true,
		'content' => aim_sc_block('[aoba_isha_clinic]'),
	));

	// プライバシーポリシー（いつも中身を合わせる）
	$specs[] = array('key' => 'privacy', 'always_sync' => true, 'args' => array(
		'title' => 'プライバシーポリシー',
		'slug' => 'privacy-policy',
		'order' => 10,
		'desc' => '全国お医者さんマップのプライバシーポリシー（個人情報・アクセス解析・位置情報の扱い、免責）です。',
		'content' => aim_sc_block('[aoba_isha_privacy]'),
	));
	return $specs;
}

/**
 * ページの作成・更新を「仕事」として登録する。実際の作業は aim_run_page_job() が少しずつ進める。
 * 一度に全ページを書き直すとサーバーの時間切れで止まることがあるため。
 */
function aim_create_pages($sync = false) {
	$ids = get_option('aim_pages', array());
	$new = 0;
	foreach (aim_page_specs() as $sp) if (empty($ids[$sp['key']])) $new++;
	update_option('aim_sync_job', array('pos' => 0, 'sync' => $sync === true ? 1 : 0, 'total' => 0, 'new' => $new), false);
}

/** 登録された仕事を、最大 $limit ページ・約15秒ぶん進める。終わったら true */
function aim_run_page_job($limit = 20) {
	$job = get_option('aim_sync_job');
	if (!is_array($job)) return true;
	// 同時に2か所で動かないように鍵をかける（2分たっても残っている鍵は古いものとして外す）
	if (!add_option('aim_sync_lock', time(), '', false)) {
		if (time() - (int) get_option('aim_sync_lock') < 120) return false;
		update_option('aim_sync_lock', time(), false);
	}
	$t0 = microtime(true);
	$specs = aim_page_specs();
	$ids = get_option('aim_pages', array());
	if (empty($ids['privacy'])) {
		$wp_priv = (int) get_option('wp_page_for_privacy_policy');
		if ($wp_priv && get_post($wp_priv)) $ids['privacy'] = $wp_priv;
	}
	$n = count($specs);
	$pos = min((int) $job['pos'], $n);
	$done = 0;
	while ($pos < $n && $done < $limit && microtime(true) - $t0 < 15) {
		$sp = $specs[$pos];
		$args = $sp['args'];
		if (!empty($sp['parent_key'])) $args['parent'] = isset($ids[$sp['parent_key']]) ? $ids[$sp['parent_key']] : 0;
		aim_ensure_page($sp['key'], $args, $ids, !empty($job['sync']) || !empty($sp['always_sync']));
		$pos++;
		$done++;
		update_option('aim_pages', $ids); // 途中で止まっても、作ったページを二重に作らないように毎回残す
	}
	// 入れ物方式にする前に作っていた駅・市区町村×診療科の固定ページは下書きに戻す（消さない。URL は入れ物が受け持つ）
	$left = $pos >= $n ? aim_retire_old_pages($ids, $t0) : 0;
	if ($pos >= $n) update_option('aim_pages', $ids);
	if ($left > 0) {
		update_option('aim_sync_job', array('pos' => $pos, 'sync' => $job['sync'], 'total' => $n, 'new' => isset($job['new']) ? $job['new'] : 1, 'retire' => 1), false);
		delete_option('aim_sync_lock');
		return false;
	}
	if ($pos >= $n) {
		if (!empty($ids['privacy'])) update_option('wp_page_for_privacy_policy', $ids['privacy']);
		// トップページを地図のページにする（まだ固定ページを表示していない場合だけ）
		if (get_option('show_on_front') !== 'page' && !empty($ids['top'])) {
			update_option('show_on_front', 'page');
			update_option('page_on_front', $ids['top']);
		}
		flush_rewrite_rules();
		delete_option('aim_sync_job');
	} else {
		update_option('aim_sync_job', array('pos' => $pos, 'sync' => $job['sync'], 'total' => $n, 'new' => isset($job['new']) ? $job['new'] : 1), false);
	}
	delete_option('aim_sync_lock');
	return $pos >= $n;
}

/** 古い1枚ずつの固定ページの鍵か（eki_{駅}・ka_{科}_{市区町村}。入れ物の鍵は除く） */
function aim_is_old_page_key($key) {
	if ($key === 'eki_host') return false;
	if (strpos($key, 'eki_') === 0) return true;
	if (strpos($key, 'ka_') !== 0 || substr($key, -5) === '_host') return false;
	$defs = aim_area_defs();
	foreach (aim_dept_groups() as $g) {
		$p = 'ka_' . $g['slug'] . '_';
		if (strpos($key, $p) === 0 && isset($defs[substr($key, strlen($p))])) return true;
	}
	return false;
}

/** 古い固定ページを少しずつ下書きにする。残りの数を返す */
function aim_retire_old_pages(&$ids, $t0) {
	global $wpdb;
	$old = array();
	foreach ($ids as $k => $id) if (aim_is_old_page_key($k)) $old[$k] = (int) $id;
	if (!$old) {
		// 鍵の記録から外れていた古いページ（二重にできたものなど）も、駅一覧・各科ページの下にあれば下書きにする
		$parents = array();
		foreach ($ids as $k => $id) if ($k === 'eki' || (strpos($k, 'ka_') === 0 && substr($k, -5) !== '_host' && aim_dept_group(substr($k, 3)))) $parents[] = (int) $id;
		if ($parents) {
			$keep = array_map('intval', array_values($ids));
			$wpdb->query("UPDATE {$wpdb->posts} SET post_status = 'draft' WHERE post_type = 'page' AND post_status = 'publish' AND post_parent IN (" . implode(',', $parents) . ") AND ID NOT IN (" . implode(',', $keep) . ")");
		}
		return 0;
	}
	foreach (array_chunk($old, 500, true) as $chunk) {
		if (microtime(true) - $t0 > 20) break;
		$list = implode(',', array_map('intval', $chunk));
		$wpdb->query("UPDATE {$wpdb->posts} SET post_status = 'draft' WHERE post_type = 'page' AND post_status = 'publish' AND ID IN ($list)");
		foreach ($chunk as $k => $id) { clean_post_cache($id); unset($ids[$k], $old[$k]); }
	}
	return count($old);
}

/** 管理画面の上に進み具合を出す */
add_action('admin_notices', function () {
	$job = get_option('aim_sync_job');
	if (!is_array($job) || !current_user_can('manage_options')) return;
	$total = !empty($job['total']) ? (int) $job['total'] : count(aim_page_specs());
	$msg = !empty($job['retire']) ? '古いページを片付けています' : 'ページを更新しています（' . (int) $job['pos'] . '／' . $total . '）';
	echo '<div class="notice notice-info"><p>全国お医者さんマップ：' . $msg . '。管理画面を何回か開き直すと進みます。</p></div>';
});

/**
 * 下書きにした古い駅・市区町村ページをゴミ箱へ移す（30日はゴミ箱から戻せる）。
 * /wp-admin/admin-post.php?action=aim_trash_old_drafts（&dry=1 で件数だけ）
 * 対象：駅一覧・各診療科ページの下にある下書きのうち、いま使っているページ（aim_pages）以外。
 */
add_action('admin_post_aim_trash_old_drafts', function () {
	if (!current_user_can('manage_options')) wp_die('forbidden');
	global $wpdb;
	@set_time_limit(120);
	$ids = (array) get_option('aim_pages', array());
	$parents = array();
	foreach ($ids as $k => $id) if ($k === 'eki' || (strpos($k, 'ka_') === 0 && substr($k, -5) !== '_host' && aim_dept_group(substr($k, 3)))) $parents[] = (int) $id;
	$keep = array_map('intval', array_values($ids));
	if (!$parents || !$keep) { echo 'AIM_TRASH none'; exit; }
	$where = "post_type = 'page' AND post_status = 'draft' AND post_parent IN (" . implode(',', $parents) . ") AND ID NOT IN (" . implode(',', $keep) . ")";
	$left = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE $where");
	if (!empty($_GET['dry'])) { echo 'AIM_TRASH dry ' . $left; exit; }
	$t0 = microtime(true); $done = 0; $now = time();
	while (microtime(true) - $t0 < 40) {
		$rows = $wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE $where LIMIT 500");
		if (!$rows) break;
		$list = implode(',', array_map('intval', $rows));
		$vals = array();
		foreach ($rows as $id) { $id = (int) $id; $vals[] = "($id,'_wp_trash_meta_status','draft')"; $vals[] = "($id,'_wp_trash_meta_time','$now')"; }
		$wpdb->query("INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value) VALUES " . implode(',', $vals));
		$wpdb->query("UPDATE {$wpdb->posts} SET post_status = 'trash' WHERE ID IN ($list)");
		foreach ($rows as $id) clean_post_cache((int) $id);
		$done += count($rows);
	}
	$left = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE $where");
	echo 'AIM_TRASH moved ' . $done . ' left ' . $left;
	exit;
});
