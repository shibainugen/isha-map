<?php
/**
 * 駅のページ /eki/{駅}/ と、市区町村×診療科のページ /ka/{科}/{市区町村}/ を「入れ物」1枚で出す。
 * 入れ物は固定ページ（駅は /eki/aim-st/、市区町村は科ごとに /ka/{科}/aim-area/）。URL に応じて中身・タイトル・説明を差し替える。
 * 何千枚も固定ページを作らないので、県を足してもページ作りやデータベースが重くならない。
 */
if (!defined('ABSPATH')) exit;

define('AIM_VHOST_ST', '駅周辺の医療機関（表示用）');
define('AIM_VHOST_KD', '市区町村の医療機関（表示用）');
define('AIM_VHOST_ST_SLUG', 'aim-st');
define('AIM_VHOST_KD_SLUG', 'aim-area');

add_action('init', function () {
	add_rewrite_tag('%aim_st%', '([a-z0-9-]+)');
	add_rewrite_tag('%aim_kd%', '([a-z0-9-]+)');
	add_rewrite_tag('%aim_ku%', '([a-z0-9-]+)');
	add_rewrite_rule('^eki/([a-z0-9-]+)/?$', 'index.php?pagename=eki/' . AIM_VHOST_ST_SLUG . '&aim_st=$matches[1]', 'top');
	add_rewrite_rule('^ka/([a-z0-9-]+)/([a-z0-9-]+)/?$', 'index.php?pagename=ka/$matches[1]/' . AIM_VHOST_KD_SLUG . '&aim_kd=$matches[1]&aim_ku=$matches[2]', 'top');
}, 5); // clinic.php の書き直し（init 10）より先に足す

/** 駅のページの中身（掲載0件なら null） */
function aim_vpage_station($slug) {
	$s = aim_station($slug);
	if (!$s) return null;
	$cnt = aim_counts();
	$n = isset($cnt['st'][$s['slug']]) ? $cnt['st'][$s['slug']] : 0;
	if (!$n) return null;
	$defs = aim_area_defs();
	$ku = isset($s['ku']) ? $s['ku'] : 'aoba';
	$kn = !empty($s['city']) ? $s['city'] : (isset($defs[$ku]) ? $defs[$ku]['full'] : '');
	$fr = aim_ekin($s['name']) === $s['name'] ? '' : '駅から';
	return array(
		'type' => 'st',
		'url' => home_url('/eki/' . $s['slug'] . '/'),
		'host' => home_url('/eki/' . AIM_VHOST_ST_SLUG . '/'),
		'host_title' => AIM_VHOST_ST,
		'noindex' => $n <= 3,
		'title' => aim_ekin($s['name']) . '周辺の病院・クリニック',
		'desc' => aim_ekin($s['name']) . '（' . $kn . '）周辺の病院・クリニック' . $n . '件を' . $fr . '近い順に掲載。診療時間・電話番号・診療科、いま診療時間内かどうか（目安）がわかります。',
		'lead' => aim_ekin($s['name']) . '（' . $kn . '）の周辺にある病院・クリニックを、' . $fr . '近い順にまとめました。最寄り' . ($fr ? '駅' : '') . 'が' . aim_ekin($s['name']) . 'になる医療機関' . $n . '件を載せています。地図の上の絞り込みで診療科を選んだり、「いま診療時間内だけ」で今開いているところを探したりできます。',
		'map' => array('station' => $s['slug'], 'dept' => '', 'area' => ''),
	);
}

/** 市区町村×診療科のページの中身（掲載0件なら null） */
function aim_vpage_kd($dept, $ku) {
	$g = aim_dept_group($dept);
	$defs = aim_area_defs();
	if (!$g || !isset($defs[$ku])) return null;
	$cnt = aim_counts();
	$m = isset($cnt['kd'][$ku][$g['slug']]) ? $cnt['kd'][$ku][$g['slug']] : 0;
	if (!$m) return null;
	return array(
		'type' => 'kd',
		'url' => home_url('/ka/' . $g['slug'] . '/' . $ku . '/'),
		'host' => home_url('/ka/' . $g['slug'] . '/' . AIM_VHOST_KD_SLUG . '/'),
		'host_title' => AIM_VHOST_KD,
		'noindex' => false,
		'title' => aim_area_name($ku) . 'の' . $g['label'],
		'desc' => aim_area_name($ku) . 'で' . $g['label'] . 'を診療している病院・クリニック' . $m . '件を最寄り駅ごとに掲載。診療時間・電話番号・いま診療時間内かどうか（目安）がわかります。',
		'lead' => aim_area_name($ku) . 'で' . $g['label'] . 'を診療している病院・クリニック' . $m . '件を、最寄り駅ごとにまとめました。' . $g['note'] . '地図では現在地から近い順に並べ替えられます。',
		'map' => array('station' => '', 'dept' => $g['slug'], 'area' => $ku),
	);
}

/** いま表示している入れ物ページの中身（入れ物でなければ null） */
function aim_vctx() {
	static $c = false;
	if ($c !== false) return $c;
	$c = null;
	if (!function_exists('get_query_var')) return $c;
	$st = get_query_var('aim_st');
	$ku = get_query_var('aim_ku');
	if ($st) $c = aim_vpage_station($st);
	elseif ($ku) $c = aim_vpage_kd(get_query_var('aim_kd'), $ku);
	return $c;
}

/** 入れ物ページ（URLの指定なし・掲載0件・知らない駅）は 404 */
add_action('template_redirect', function () {
	if (!is_singular('page')) return;
	$p = get_queried_object();
	if (!$p || !in_array($p->post_name, array(AIM_VHOST_ST_SLUG, AIM_VHOST_KD_SLUG), true)) return;
	if (aim_vctx()) return;
	global $wp_query;
	add_filter('redirect_canonical', '__return_false');
	$wp_query->set_404();
	status_header(404);
	nocache_headers();
}, 1);

// 検索に載せるか（入れ物ページの「載せない」印は引き継がない）
add_filter('wp_robots', function ($robots) {
	$c = aim_vctx();
	if (!$c) return $robots;
	unset($robots['noindex'], $robots['follow']);
	if ($c['noindex']) { $robots['noindex'] = true; $robots['follow'] = true; unset($robots['index']); }
	return $robots;
}, 100);

add_action('wp_head', function () {
	$c = aim_vctx();
	if ($c) echo '<meta name="description" content="' . esc_attr($c['desc']) . '">' . "\n";
}, 1);

/** ページ全体の HTML で、入れ物のタイトル・URL をこのページのものに置き換える（design.php の仕上げから呼ぶ） */
function aim_vpage_fix_html($html) {
	$c = aim_vctx();
	if (!$c) return $html;
	$html = str_replace($c['host_title'], esc_html($c['title']), $html);
	foreach (array('"', "'") as $q) $html = str_replace($c['host'] . $q, $c['url'] . $q, $html);
	$html = preg_replace('#<link rel=[\'"]shortlink[\'"][^>]*>\s*#i', '', $html);
	return $html;
}

/** [aoba_isha_vpage] 入れ物ページの本文 */
add_shortcode('aoba_isha_vpage', function () {
	$c = aim_vctx();
	if (!$c) return '';
	$m = $c['map'];
	$h = '<p>' . $c['lead'] . '</p>' . "\n\n";
	$h .= do_shortcode('[aoba_isha_map station="' . $m['station'] . '" dept="' . $m['dept'] . '" area="' . $m['area'] . '"]') . "\n\n";
	$h .= do_shortcode('[aoba_isha_list station="' . $m['station'] . '" dept="' . $m['dept'] . '" area="' . $m['area'] . '"]');
	return $h;
});

/** 駅・市区町村×診療科ページの URL（掲載0件なら ''）。aim_page_url() から呼ぶ */
function aim_vpage_url($key) {
	if (strpos($key, 'eki_') === 0) {
		$c = aim_vpage_station(substr($key, 4));
		return $c ? $c['url'] : '';
	}
	if (strpos($key, 'ka_') === 0) {
		foreach (aim_dept_groups() as $g) {
			$p = 'ka_' . $g['slug'] . '_';
			if (strpos($key, $p) !== 0) continue;
			$c = aim_vpage_kd($g['slug'], substr($key, strlen($p)));
			return $c ? $c['url'] : '';
		}
	}
	return null; // 入れ物ページではない（固定ページ）
}

// サイトマップ：駅（掲載4件以上）と、市区町村×診療科のページ
add_action('init', function () {
	if (!function_exists('wp_register_sitemap_provider') || !class_exists('WP_Sitemaps_Provider')) return;
	if (!class_exists('AIM_VPage_Sitemap')) {
		class AIM_VPage_Sitemap extends WP_Sitemaps_Provider {
			const PER = 2000;
			private $kind;
			public function __construct($kind) { $this->kind = $kind; $this->name = $kind; $this->object_type = $kind; }
			private function urls() {
				static $u = array();
				if (isset($u[$this->kind])) return $u[$this->kind];
				$out = array();
				if ($this->kind === 'eki') {
					foreach (aim_stations() as $s) { $c = aim_vpage_station($s['slug']); if ($c && !$c['noindex']) $out[] = $c['url']; }
				} else {
					$cnt = aim_counts();
					foreach (aim_dept_groups() as $g) foreach (aim_area_defs() as $ku => $d) if (!empty($cnt['kd'][$ku][$g['slug']])) $out[] = home_url('/ka/' . $g['slug'] . '/' . $ku . '/');
				}
				return $u[$this->kind] = $out;
			}
			public function get_url_list($page_num, $object_subtype = '') {
				return array_map(function ($l) { return array('loc' => $l); }, array_slice($this->urls(), ($page_num - 1) * self::PER, self::PER));
			}
			public function get_max_num_pages($object_subtype = '') { return (int) ceil(count($this->urls()) / self::PER); }
		}
	}
	wp_register_sitemap_provider('eki', new AIM_VPage_Sitemap('eki'));
	wp_register_sitemap_provider('kaarea', new AIM_VPage_Sitemap('kaarea'));
}, 20);
