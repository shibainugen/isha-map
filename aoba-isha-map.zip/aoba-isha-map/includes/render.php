<?php
if (!defined('ABSPATH')) exit;

function aim_page_url($key) {
	if (function_exists('aim_vpage_url')) { $v = aim_vpage_url($key); if ($v !== null) return $v; }
	static $primed = false;
	$ids = get_option('aim_pages', array());
	if (!$primed && function_exists('_prime_post_caches') && $ids) { $primed = true; _prime_post_caches(array_map('intval', array_values($ids)), false, false); }
	if (empty($ids[$key])) return '';
	$u = get_permalink($ids[$key]);
	return $u ? $u : '';
}

function aim_render_card($f, $show_station) {
	$st = aim_station($f['st']);
	$name = !empty($f['short']) ? $f['short'] : $f['name'];
	$h = '<li class="aip-card">';
	$h .= '<h3 class="aip-name"><a href="' . esc_url(home_url('/clinic/' . $f['id'] . '/')) . '">' . esc_html($name) . '</a></h3>';
	if ($name !== $f['name']) $h .= '<p class="aip-formal">' . esc_html($f['name']) . '</p>';
	$h .= '<p class="aip-addr">' . esc_html(str_replace('神奈川県', '', $f['addr'])) . '</p>';
	$meta = array();
	if ($st && $f['stm'] > 2500) $meta[] = esc_html(aim_ekin($st['name'])) . 'から直線' . number_format($f['stm'] / 1000, 1) . 'km（バスや車が便利）';
	elseif ($st) $meta[] = esc_html(aim_ekin($st['name'])) . 'から約' . aim_walk($f['stm']) . '分（直線' . number_format($f['stm']) . 'm）';
	if (!empty($f['tel'])) $meta[] = '☎ <a href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $f['tel'])) . '">' . esc_html($f['tel']) . '</a>';
	if ($meta) $h .= '<p class="aip-meta">' . implode('　', $meta) . '</p>';
	$h .= '<p class="aip-deps"><span class="aip-pill aip-kind">' . esc_html($f['kind']) . '</span>';
	foreach (array_slice((array) $f['deps'], 0, 10) as $d) $h .= '<span class="aip-pill">' . esc_html($d) . '</span>';
	if (count((array) $f['deps']) > 10) $h .= '<span class="aip-pill">ほか' . (count($f['deps']) - 10) . '科</span>';
	$h .= '</p>';
	if (aim_has_hours($f)) {
		$h .= '<details class="aip-hours"><summary>診療時間</summary><table>';
		foreach (aim_hours_rows($f) as $r) $h .= '<tr><th>' . esc_html($r[0]) . '</th><td>' . esc_html($r[1]) . '</td></tr>';
		$h .= '</table></details>';
	} else {
		$h .= '<p class="aip-meta">診療時間の届け出がありません。医療機関にお問い合わせください。</p>';
	}
	$links = array();
	if (!empty($f['url'])) $links[] = '<a href="' . esc_url($f['url']) . '" target="_blank" rel="noopener nofollow">ホームページ</a>';
	$links[] = '<a href="' . esc_url('https://www.google.com/maps/dir/?api=1&destination=' . $f['lat'] . ',' . $f['lng']) . '" target="_blank" rel="noopener">道順を見る</a>';
	$h .= '<p class="aip-links">' . implode('', $links) . '</p>';
	$h .= '</li>';
	return $h;
}

// 一覧は駅・市区町村のファイルだけ読んで作るので軽い。何千ページ分をデータベースに覚えさせないよう、毎回作る
function aim_render_list($station, $dept, $area = '') { return aim_render_list_raw($station, $dept, $area); }
function aim_render_list_raw($station, $dept, $area = '') {
	$rows = aim_filter($station, $dept, $area);
	if (!$rows) return '<p class="aip-empty">条件に合う医療機関はありませんでした。</p>';
	$h = '<div class="aip">';
	if ($station) {
		$h .= '<ul class="aip-cards">';
		foreach ($rows as $f) $h .= aim_render_card($f, false);
		$h .= '</ul>';
	} elseif ($area) {
		// 市区×診療科のページは最寄り駅ごとに見出しを分ける
		$by = array();
		foreach ($rows as $f) $by[$f['st']][] = $f;
		$h .= '<nav class="aip-jump">';
		foreach ($by as $slug => $list) {
			$st = aim_station($slug);
			$h .= '<a href="#st-' . esc_attr($slug) . '">' . esc_html($st['name']) . '（' . count($list) . '）</a>';
		}
		$h .= '</nav>';
		foreach ($by as $slug => $list) {
			$st = aim_station($slug);
			$h .= '<h2 id="st-' . esc_attr($slug) . '" class="aip-h">' . esc_html(aim_ekin($st['name'])) . '周辺</h2><ul class="aip-cards">';
			foreach ($list as $f) $h .= aim_render_card($f, true);
			$h .= '</ul>';
		}
	} else {
		// 診療科ページは件数が多いので、市区ごと→駅ごとの短い一覧にする（詳しい情報は駅のページ）
		$defs = aim_area_defs();
		$by = array();
		foreach ($rows as $f) $by[$f['ku']][$f['st']][] = $f;
		$order = array_values(array_filter(array_keys($defs), function ($k) use ($by) { return isset($by[$k]); }));
		$h .= '<nav class="aip-jump">';
		foreach ($order as $ku) {
			$n = 0; foreach ($by[$ku] as $l) $n += count($l);
			$h .= '<a href="#area-' . esc_attr($ku) . '">' . esc_html($defs[$ku]['full']) . '（' . $n . '）</a>';
		}
		$h .= '</nav>';
		$h .= '<p class="aip-meta">駅名を押すと、その駅のページで各医療機関の診療時間・地図などを見られます。</p>';
		foreach ($order as $ku) {
			$h .= '<h2 id="area-' . esc_attr($ku) . '" class="aip-h">' . esc_html($defs[$ku]['full']) . '</h2>';
			foreach ($by[$ku] as $slug => $list) {
				$st = aim_station($slug);
				$su = aim_page_url('eki_' . $slug);
				$h .= '<p class="aip-sth">' . ($su ? '<a href="' . esc_url($su) . '">' . esc_html(aim_ekin($st['name'])) . '</a>' : esc_html(aim_ekin($st['name']))) . '周辺</p><ul class="aip-rows">';
				foreach ($list as $f) {
					$name = !empty($f['short']) ? $f['short'] : $f['name'];
					$h .= '<li>' . esc_html($name);
					$h .= '<span>' . ($f['stm'] > 2500 ? '直線' . number_format($f['stm'] / 1000, 1) . 'km' : '徒歩約' . aim_walk($f['stm']) . '分');
					if (!empty($f['tel'])) $h .= '・<a href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $f['tel'])) . '">' . esc_html($f['tel']) . '</a>';
					$h .= '</span></li>';
				}
				$h .= '</ul>';
			}
		}
	}
	$h .= aim_source_note();
	$h .= '</div>';
	return $h;
}

function aim_source_note() {
	$d = aim_meta();
	return '<p class="aip-note">診療時間は厚生労働省「医療情報ネット（ナビイ）」オープンデータ（' . esc_html($d['asof']) . '時点）、電話番号は各地方厚生局（北海道・東北・関東信越・東海北陸・近畿・中国四国・九州）の「保険医療機関の指定一覧」（' . esc_html(isset($d['telAsof']) ? $d['telAsof'] : '') . '現在）によります。変わっている場合があるので、受診前に必ず医療機関へご確認ください。駅からの時間は直線距離をもとにした目安です。</p>';
}

function aim_render_index($type, $dept = '') { return aim_cache('index|' . $type . '|' . $dept, function () use ($type, $dept) { return aim_render_index_raw($type, $dept); }); }
function aim_render_index_raw($type, $dept = '') {
	if ($type === 'station_entry') {
		// トップ用：都県→市区町村名を押すと、駅の一覧ページのその市区町村が開く
		$base = aim_page_url('eki');
		$h = '<p class="aip-small">都県の名前を押して、市区町村を選んでください。</p>';
		foreach (aim_areas_by_pref() as $pref => $areas) {
			$h .= '<details class="aip-pref"><summary>' . esc_html($pref) . '<small>' . count($areas) . '市区町村</small></summary><ul class="aip-chips">';
			foreach ($areas as $ku => $a) $h .= '<li><a href="' . esc_url($base . '#st-' . $ku) . '">' . esc_html($a['label']) . '</a></li>';
			$h .= '</ul></details>';
		}
		return $h;
	}
	if ($type === 'dept_areas') {
		$g = aim_dept_group($dept);
		if (!$g) return '';
		$cnt = aim_counts();
		$h = '<h2 class="aip-h">市区町村から選ぶ</h2><p class="aip-small">都県の名前を押すと、市区町村の一覧が開きます。</p>';
		foreach (aim_areas_by_pref() as $pref => $areas) {
			$li = ''; $k = 0;
			foreach ($areas as $ku => $d) {
				$m = isset($cnt['kd'][$ku][$g['slug']]) ? $cnt['kd'][$ku][$g['slug']] : 0;
				if (!$m) continue;
				$u = aim_page_url('ka_' . $g['slug'] . '_' . $ku);
				$li .= '<li><a href="' . esc_url($u) . '">' . esc_html(aim_area_name($ku)) . '</a></li>';
				$k++;
			}
			if ($li) $h .= '<details class="aip-pref"><summary>' . esc_html($pref) . '<small>' . $k . '市区町村</small></summary><ul class="aip-chips">' . $li . '</ul></details>';
		}
		return $h;
	}
	$h = '<ul class="aip-index aip-index-' . esc_attr($type === 'dept' ? 'dept' : 'st') . '">';
	if ($type === 'dept') {
		$cnt = aim_counts();
		foreach (aim_dept_groups() as $g) {
			$n = isset($cnt['dept'][$g['slug']]) ? $cnt['dept'][$g['slug']] : 0;
			if (!$n) continue;
			$u = add_query_arg('ka', $g['slug'], home_url('/')) . '#aim';
			$h .= '<li><a href="' . esc_url($u) . '" rel="nofollow"><i class="aip-ic" aria-hidden="true">' . aim_dept_icon($g['slug']) . '</i><span>' . esc_html($g['label']) . '</span><small>近い順に探す</small></a></li>';
		}
		$h .= '</ul>';
		// 市区町村ごとの一覧へ（検索から来る人と、検索エンジンのための道）
		$li = '';
		foreach (aim_dept_groups() as $g) {
			if (empty($cnt['dept'][$g['slug']])) continue;
			$li .= '<li><a href="' . esc_url(aim_page_url('ka_' . $g['slug'])) . '">' . esc_html($g['label']) . '</a></li>';
		}
		$h .= '<details class="aip-pref aip-dept-areas"><summary>市区町村の一覧から選ぶ<small>科を選ぶと市区町村の一覧へ</small></summary><ul class="aip-chips">' . $li . '</ul></details>';
		return $h;
	} else {
		$h = '';
		$cnt = aim_counts();
		$wards = aim_wards();
		$pi = 0;
		foreach (aim_areas_by_pref() as $pref => $areas) {
			$body = ''; $ns = 0;
			foreach ($areas as $ku => $a) {
				$items = ''; $nk = 0;
				foreach (aim_stations() as $s) {
					if ((isset($s['ku']) ? $s['ku'] : 'aoba') !== $ku) continue;
					$n = isset($cnt['st'][$s['slug']]) ? $cnt['st'][$s['slug']] : 0;
					if (!$n) continue;
					$u = aim_page_url('eki_' . $s['slug']);
					$ln = aim_station_line($s['slug']);
					$em = $ln[0] . (!empty($s['city']) ? '・' . $s['city'] : '');
					$items .= '<li><a class="aip-st aip-st-' . esc_attr($ln[1]) . '" href="' . esc_url($u) . '"><em>' . esc_html($em) . '</em><span>' . esc_html($s['name']) . (aim_ekin($s['name']) === $s['name'] ? '' : '<b>駅</b>') . '</span><small>' . $n . '件</small></a></li>';
					$ns++; $nk++;
				}
				// 市区町村ごとにたたむ（押すと開く）
				if ($items) $body .= '<details class="aip-ku" id="st-' . esc_attr($ku) . '"><summary>' . esc_html($wards[$ku]) . 'の駅<small>' . $nk . '駅</small></summary><ul class="aip-index aip-index-st">' . $items . '</ul></details>';
			}
			if ($body) $h .= '<details class="aip-pref" id="pref-' . (++$pi) . '"><summary>' . esc_html($pref) . 'の駅<small>' . $ns . '駅</small></summary>' . $body . '</details>';
		}
		$h .= '<script>(function(){function o(){var i=location.hash.slice(1);if(!i)return;var e=document.getElementById(i);if(!e)return;for(var d=e;d;d=d.parentElement){if(d.tagName==="DETAILS")d.open=true;}e.scrollIntoView();}window.addEventListener("hashchange",o);o();})();</script>';
		return $h;
	}
	return $h . '</ul>';
}

function aim_render_links() {
	$h = '<div class="aip">';
	$h .= '<p class="aip-alert">急に具合が悪くなった・休日や夜に受診したいときは <a href="' . esc_url(aim_page_url('emergency')) . '">休日・夜間の受診案内</a> へ。命に関わるときは迷わず <strong>119</strong>。</p>';
	$navi = aim_page_url('navi');
	if ($navi) $h .= '<p class="aip-navi"><a href="' . esc_url($navi) . '"><strong>症状から何科か調べる</strong><span>頭痛・腹痛・発熱・発疹… いくつか答えるだけで受診先の目安がわかります</span></a></p>';
	$h .= '<h2 class="aip-h">駅から探す</h2>' . aim_render_index('station_entry');
	$h .= '<h2 class="aip-h">診療科から探す</h2>' . aim_render_index('dept');
	return $h . '</div>';
}
