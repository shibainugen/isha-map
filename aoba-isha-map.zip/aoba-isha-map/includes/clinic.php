<?php
/**
 * 医療機関ごとのページ /clinic/{id}/
 * 実体は固定ページ「clinic」1枚。URL の id で中身を差し替える（3万ページを作らずに済む）。
 * データは data/fac/{md5(id)の先頭2文字}.json（pipeline/build_fac.py で作る）。
 */
if (!defined('ABSPATH')) exit;

define('AIM_CLINIC_HOST_TITLE', '医療機関の詳細');

add_action('init', function () {
	add_rewrite_tag('%aim_clinic%', '([0-9A-Z]{6,15})');
	add_rewrite_rule('^clinic/([0-9A-Z]{6,15})/?$', 'index.php?pagename=clinic&aim_clinic=$matches[1]', 'top');
	// ルールを足した版で一度だけ書き直す
	if (get_option('aim_rw_ver') !== AOBA_ISHA_MAP_VER) {
		flush_rewrite_rules(false);
		update_option('aim_rw_ver', AOBA_ISHA_MAP_VER, true);
	}
});

function aim_clinic_url($id) { return home_url('/clinic/' . $id . '/'); }

/** id の医療機関（無ければ null） */
function aim_clinic($id) {
	static $cache = array();
	$id = (string) $id;
	if (!preg_match('/^[0-9A-Z]{6,15}$/', $id)) return null;
	$k = substr(md5($id), 0, 2);
	if (!isset($cache[$k])) {
		$raw = @file_get_contents(AOBA_ISHA_MAP_DIR . 'data/fac/' . $k . '.json');
		$cache[$k] = $raw ? json_decode($raw, true) : array();
	}
	return isset($cache[$k][$id]) ? $cache[$k][$id] : null;
}

/** いま表示している医療機関（/clinic/{id}/ のときだけ） */
function aim_current_clinic() {
	static $f = false;
	if ($f !== false) return $f;
	$id = get_query_var('aim_clinic');
	$f = $id ? aim_clinic($id) : null;
	return $f;
}

/** 検索に載せてよいか（診療時間と電話番号がそろっているもの） */
function aim_clinic_complete($f) {
	return $f && !empty($f['tel']) && aim_has_hours($f);
}

function aim_clinic_name($f) { return !empty($f['short']) ? $f['short'] : aim_short_name($f['name']); }

function aim_clinic_title($f) {
	return aim_clinic_name($f) . '（' . aim_area_name($f['ku']) . '）の診療時間・電話番号・アクセス';
}

function aim_clinic_desc($f) {
	$deps = array_slice((array) $f['deps'], 0, 5);
	$s = aim_clinic_name($f) . '（' . preg_replace('/^(北海道|青森県|岩手県|宮城県|秋田県|山形県|福島県|茨城県|栃木県|群馬県|埼玉県|千葉県|東京都|神奈川県|新潟県|富山県|石川県|福井県|山梨県|長野県|岐阜県|静岡県|愛知県|三重県|滋賀県|京都府|大阪府|兵庫県|奈良県|和歌山県|鳥取県|島根県|岡山県|広島県|山口県|徳島県|香川県|愛媛県|高知県|福岡県|佐賀県|長崎県|熊本県|大分県|宮崎県|鹿児島県|沖縄県)/u', '', $f['addr']) . '）の診療時間・電話番号';
	if ($deps) $s .= '・診療科（' . implode('、', $deps) . (count($f['deps']) > 5 ? 'ほか' : '') . '）';
	if (!empty($f['stn'])) $s .= '・最寄り駅（' . aim_ekin($f['stn']) . 'から' . ($f['stm'] > 2500 ? '約' . number_format($f['stm'] / 1000, 1) . 'km' : '徒歩約' . aim_walk($f['stm']) . '分') . '）';
	return $s . '。いま診療時間内かどうか（目安）もわかります。';
}

/** 都県＋郡を外した住所 */
function aim_clinic_pref($f) {
	return preg_match('/^(北海道|青森県|岩手県|宮城県|秋田県|山形県|福島県|茨城県|栃木県|群馬県|埼玉県|千葉県|東京都|神奈川県|新潟県|富山県|石川県|福井県|山梨県|長野県|岐阜県|静岡県|愛知県|三重県|滋賀県|京都府|大阪府|兵庫県|奈良県|和歌山県|鳥取県|島根県|岡山県|広島県|山口県|徳島県|香川県|愛媛県|高知県|福岡県|佐賀県|長崎県|熊本県|大分県|宮崎県|鹿児島県|沖縄県)/u', $f['addr'], $m) ? $m[1] : '';
}

// /clinic/ だけ（id なし）や、存在しない id の扱い
add_action('template_redirect', function () {
	if (!is_page('clinic')) return;
	$id = get_query_var('aim_clinic');
	if (!$id) { wp_safe_redirect(home_url('/'), 301); exit; }
	if (!aim_current_clinic()) {
		global $wp_query;
		add_filter('redirect_canonical', '__return_false'); // 入れ物ページへ飛ばされないように
		$wp_query->set_404();
		status_header(404);
		nocache_headers();
	}
}, 1);

// 診療時間などがそろっていない所は検索に載せない
add_filter('wp_robots', function ($robots) {
	$f = aim_current_clinic();
	if (!$f) return $robots;
	unset($robots['noindex'], $robots['follow']); // 入れ物ページの印は引き継がない
	if (!aim_clinic_complete($f)) { $robots['noindex'] = true; $robots['follow'] = true; }
	return $robots;
}, 100);

add_filter('wp_head', function () {
	$f = aim_current_clinic();
	if (!$f) return;
	echo '<meta name="description" content="' . esc_attr(aim_clinic_desc($f)) . '">' . "\n";
	echo '<script type="application/ld+json">' . wp_json_encode(aim_clinic_jsonld($f), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
}, 2);

/** ページ全体の HTML で、入れ物ページのタイトル・URL をこの医療機関のものに置き換える */
function aim_clinic_fix_html($html) {
	$f = aim_current_clinic();
	if (!$f) return $html;
	$title = esc_html(aim_clinic_title($f));
	$url = aim_clinic_url($f['id']);
	$host = home_url('/clinic/');
	$html = str_replace(AIM_CLINIC_HOST_TITLE, $title, $html);
	foreach (array('"', "'") as $q) $html = str_replace($host . $q, $url . $q, $html);
	$html = preg_replace('#<link rel=[\'"]shortlink[\'"][^>]*>\s*#i', '', $html);
	// 入れ物ページの説明文（あれば）を外す。正しい説明文は wp_head で出している
	return $html;
}

function aim_clinic_jsonld($f) {
	$dow = array('月' => 'Monday', '火' => 'Tuesday', '水' => 'Wednesday', '木' => 'Thursday', '金' => 'Friday', '土' => 'Saturday', '日' => 'Sunday');
	$oh = array();
	foreach ($dow as $j => $e) {
		foreach ((array) ($f['hours'][$j] ?? array()) as $span) {
			if (preg_match('/^(\d{1,2}:\d{2})-(\d{1,2}:\d{2})$/', $span, $m)) $oh[] = array('@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $e, 'opens' => $m[1], 'closes' => $m[2]);
		}
	}
	$o = array(
		'@context' => 'https://schema.org',
		'@type' => $f['kind'] === '病院' ? 'Hospital' : 'MedicalClinic',
		'name' => $f['name'],
		'url' => aim_clinic_url($f['id']),
		'address' => array('@type' => 'PostalAddress', 'streetAddress' => $f['addr'], 'addressRegion' => aim_clinic_pref($f), 'addressCountry' => 'JP'),
		'geo' => array('@type' => 'GeoCoordinates', 'latitude' => $f['lat'], 'longitude' => $f['lng']),
	);
	if (!empty($f['tel'])) $o['telephone'] = $f['tel'];
	if (!empty($f['url'])) $o['sameAs'] = $f['url'];
	if ($oh) $o['openingHoursSpecification'] = $oh;
	$crumbs = array(array('トップ', home_url('/')));
	if (!empty($f['stn'])) {
		$crumbs[] = array('駅から探す', home_url('/eki/'));
		$crumbs[] = array(aim_ekin($f['stn']) . '周辺', home_url('/eki/' . $f['st'] . '/'));
	}
	$crumbs[] = array(aim_clinic_name($f), aim_clinic_url($f['id']));
	$bl = array('@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array());
	foreach ($crumbs as $i => $c) $bl['itemListElement'][] = array('@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1]);
	return array($o, $bl);
}

/** [aoba_isha_clinic] 医療機関1件の詳しいページ */
add_shortcode('aoba_isha_clinic', function () {
	wp_enqueue_style('aoba-isha-pages');
	$f = aim_current_clinic();
	if (!$f) return '<p>お探しの医療機関は見つかりませんでした。<a href="' . esc_url(home_url('/')) . '">トップページ</a>から探してください。</p>';
	$name = aim_clinic_name($f);
	$area = aim_area_name($f['ku']);
	$addr = $f['addr'];
	$walk = '';
	if (!empty($f['stn'])) $walk = $f['stm'] > 2500 ? aim_ekin($f['stn']) . 'から直線約' . number_format($f['stm'] / 1000, 1) . 'km（バスや車が便利）' : aim_ekin($f['stn']) . 'から徒歩約' . aim_walk($f['stm']) . '分（直線' . number_format($f['stm']) . 'm）';
	$h = '<div class="aic">';

	// 道しるべ
	$h .= '<nav class="aic-bc"><a href="' . esc_url(home_url('/')) . '">トップ</a> › ';
	if (!empty($f['stn'])) $h .= '<a href="' . esc_url(home_url('/eki/' . $f['st'] . '/')) . '">' . esc_html(aim_ekin($f['stn'])) . '周辺</a> › ';
	$h .= '<span>' . esc_html($name) . '</span></nav>';

	// ひとことで
	$deps = (array) $f['deps'];
	$lead = esc_html($name) . 'は、' . esc_html(aim_clinic_pref($f) . $area) . 'にある' . esc_html($f['kind']) . 'です。';
	if ($walk) $lead .= '最寄り' . (aim_ekin($f['stn']) === $f['stn'] ? 'は' : '駅は') . esc_html(aim_ekin($f['stn'])) . 'で、' . esc_html(preg_replace('/^(道の駅[^か]*|.+?(駅|港|ステーション|センター|ターミナル|プラザ|バス停))から/u', '', $walk)) . 'です。';
	if ($deps) $lead .= '診療科は' . esc_html(implode('・', array_slice($deps, 0, 8))) . (count($deps) > 8 ? 'など' . count($deps) . '科' : '') . 'を届け出ています。';
	$h .= '<p class="aic-lead">' . $lead . '</p>';

	// いま診療時間内か（目安）。時刻は見る人の端末で計算する
	if (aim_has_hours($f)) {
		$h .= '<p class="aic-now" data-hours="' . esc_attr(wp_json_encode($f['hours'])) . '" data-hol="' . esc_attr($f['hol'] ?? '') . '"></p>';
	}

	// 基本情報
	$h .= '<h2>基本情報</h2><table class="aic-info">';
	$h .= '<tr><th>名称</th><td>' . esc_html($f['name']) . '</td></tr>';
	$h .= '<tr><th>種別</th><td>' . esc_html($f['kind']) . '</td></tr>';
	$h .= '<tr><th>住所</th><td>' . esc_html($addr) . '<br><a href="' . esc_url('https://www.google.com/maps/search/?api=1&query=' . $f['lat'] . ',' . $f['lng']) . '" target="_blank" rel="noopener">地図アプリで開く</a>　<a href="' . esc_url('https://www.google.com/maps/dir/?api=1&destination=' . $f['lat'] . ',' . $f['lng']) . '" target="_blank" rel="noopener">道順を見る</a></td></tr>';
	if (!empty($f['tel'])) $h .= '<tr><th>電話</th><td><a href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $f['tel'])) . '">' . esc_html($f['tel']) . '</a></td></tr>';
	if ($walk) $h .= '<tr><th>最寄り駅</th><td><a href="' . esc_url(home_url('/eki/' . $f['st'] . '/')) . '">' . esc_html(aim_ekin($f['stn'])) . '</a>から' . esc_html(preg_replace('/^(道の駅[^か]*|.+?(駅|港|ステーション|センター|ターミナル|プラザ|バス停))から/u', '', $walk)) . '</td></tr>';
	if ($deps) {
		$h .= '<tr><th>診療科</th><td class="aic-deps">';
		foreach ($deps as $d) $h .= '<span class="aip-pill">' . esc_html($d) . '</span>';
		$h .= '</td></tr>';
	}
	if (!empty($f['url'])) $h .= '<tr><th>ホームページ</th><td><a href="' . esc_url($f['url']) . '" target="_blank" rel="noopener nofollow">' . esc_html(preg_replace('#^https?://#', '', rtrim($f['url'], '/'))) . '</a></td></tr>';
	$h .= '</table>';

	// 診療時間
	$h .= '<h2>診療時間</h2>';
	if (aim_has_hours($f)) {
		$h .= '<table class="aic-hours">';
		foreach (aim_hours_rows($f) as $r) $h .= '<tr><th>' . esc_html($r[0]) . '</th><td>' . esc_html($r[1]) . '</td></tr>';
		$h .= '</table><p class="aic-note">届け出の時間です。休診日・受付終了時間・予約の要否は変わることがあります。受診前にお電話か医療機関のホームページで確認してください。</p>';
	} else {
		$h .= '<p>診療時間の届け出がありません。医療機関にお問い合わせください。</p>';
	}

	// 地図
	$dlat = 0.004; $dlng = 0.006;
	$bbox = ($f['lng'] - $dlng) . ',' . ($f['lat'] - $dlat) . ',' . ($f['lng'] + $dlng) . ',' . ($f['lat'] + $dlat);
	$h .= '<h2>地図</h2><div class="aic-map"><iframe title="' . esc_attr($name) . 'の地図" loading="lazy" src="' . esc_url('https://www.openstreetmap.org/export/embed.html?bbox=' . $bbox . '&layer=mapnik&marker=' . $f['lat'] . ',' . $f['lng']) . '"></iframe></div>';

	// 近くの同じ科
	if (!empty($f['near']) && !empty($f['nd'])) {
		$h .= '<h2>近くの' . esc_html($f['nd']) . '</h2><ul class="aic-near">';
		foreach ($f['near'] as $n) {
			$h .= '<li><a href="' . esc_url(aim_clinic_url($n[0])) . '">' . esc_html($n[1]) . '</a><small>' . esc_html($n[2]) . '・' . ($n[3] >= 1000 ? number_format($n[3] / 1000, 1) . 'km' : $n[3] . 'm') . '</small></li>';
		}
		$h .= '</ul>';
	}

	// 一覧へ
	$links = array();
	if (!empty($f['stn'])) $links[] = '<a href="' . esc_url(home_url('/eki/' . $f['st'] . '/')) . '">' . esc_html(aim_ekin($f['stn'])) . '周辺の病院・クリニック</a>';
	foreach (aim_dept_groups() as $g) {
		if (aim_in_group($f, $g)) $links[] = '<a href="' . esc_url(home_url('/ka/' . $g['slug'] . '/' . $f['ku'] . '/')) . '">' . esc_html($area . 'の' . $g['label']) . '</a>';
	}
	$links[] = '<a href="' . esc_url(home_url('/kyujitsu-yakan/')) . '">休日・夜間に具合が悪くなったら</a>';
	$h .= '<h2>ほかの病院・クリニックを探す</h2><ul class="aic-links"><li>' . implode('</li><li>', $links) . '</li></ul>';

	$m = aim_meta();
	$h .= '<p class="aic-src">掲載情報は厚生労働省 医療情報ネット（ナビイ）のオープンデータ（' . esc_html($m['asof']) . '時点）と各地方厚生局（関東信越・東海北陸・近畿）の保険医療機関の一覧をもとにしています。内容に誤りや変更があれば <a href="mailto:isha@re-kaitori.jp?subject=' . rawurlencode('掲載内容の修正：' . $f['name']) . '">isha@re-kaitori.jp</a> までお知らせください。</p>';
	$h .= '</div>';
	if (aim_has_hours($f)) $h .= aim_clinic_now_js();
	return $h;
});

function aim_clinic_now_js() {
	return '<script>(function(){var e=document.querySelector(".aic-now");if(!e)return;var H=JSON.parse(e.dataset.hours||"{}");'
		. 'var n=new Date(Date.now()+(9*60+new Date().getTimezoneOffset())*60000),D=["日","月","火","水","木","金","土"][n.getDay()],m=n.getHours()*60+n.getMinutes();'
		. 'function t(s){var a=s.split(":");return +a[0]*60+ +a[1];}var o=null,nx=null;if((H[D]||[]).some(function(s){return s.charAt(0)==="?";})){e.className+=" closed";e.textContent="きょうの診療時間は要確認";return;}(H[D]||[]).forEach(function(s){var p=s.split("-");if(p.length<2)return;var a=t(p[0]),b=t(p[1]);if(m>=a&&m<b)o=p[1];else if(m<a&&nx===null)nx=p[0];});'
		. 'e.className+=o?" open":" closed";e.textContent=o?"いま診療時間内（"+o+"まで）":(nx?"いまは時間外（きょうは"+nx+"から）":"きょうの診療は終了または休診");'
		. 'e.title="届け出の時間から判断した目安です。祝日・臨時休診は反映していません";})();</script>';
}

// サイトマップに医療機関のページを足す（診療時間と電話がそろっている所だけ）
add_action('init', function () {
	if (!function_exists('wp_register_sitemap_provider') || !class_exists('WP_Sitemaps_Provider')) return;
	if (!class_exists('AIM_Clinic_Sitemap')) {
		class AIM_Clinic_Sitemap extends WP_Sitemaps_Provider {
			const PER = 2000;
			public function __construct() { $this->name = 'clinic'; $this->object_type = 'clinic'; }
			private function ids() {
				static $ids = null;
				if ($ids === null) { $raw = @file_get_contents(AOBA_ISHA_MAP_DIR . 'data/fac/index.json'); $ids = $raw ? json_decode($raw, true) : array(); }
				return $ids;
			}
			public function get_url_list($page_num, $object_subtype = '') {
				$out = array();
				foreach (array_slice($this->ids(), ($page_num - 1) * self::PER, self::PER) as $id) $out[] = array('loc' => aim_clinic_url($id));
				return $out;
			}
			public function get_max_num_pages($object_subtype = '') { return (int) ceil(count($this->ids()) / self::PER); }
		}
	}
	wp_register_sitemap_provider('clinic', new AIM_Clinic_Sitemap());
}, 20);
