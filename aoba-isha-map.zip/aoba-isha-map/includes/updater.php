<?php
if (!defined('ABSPATH')) exit;

/**
 * 自動更新：GitHub（shibainugen/isha-map の release ブランチ）に置いた最新版を、WordPress の
 * 「プラグインの更新」の仕組みで取りにいく。手でzipをアップロードしなくてよくなる。
 * release ブランチには version.json と aoba-isha-map.zip だけを置く。
 */
define('AIM_UPDATE_JSON', 'https://raw.githubusercontent.com/shibainugen/isha-map/release/version.json');

function aim_remote_version() {
	static $info = null;
	if ($info !== null) return $info;
	$info = false;
	$r = wp_remote_get(AIM_UPDATE_JSON . '?t=' . time(), array('timeout' => 10));
	if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) return $info;
	$j = json_decode(wp_remote_retrieve_body($r), true);
	if (is_array($j) && !empty($j['version']) && !empty($j['zip'])) $info = $j;
	return $info;
}

// 更新があるか確かめるときに、この版の情報を足す
add_filter('pre_set_site_transient_update_plugins', function ($t) {
	if (!is_object($t)) return $t;
	$info = aim_remote_version();
	if (!$info) return $t;
	$file = plugin_basename(AOBA_ISHA_MAP_FILE);
	$item = (object) array(
		'id' => 'isha-map/' . $file,
		'slug' => 'aoba-isha-map',
		'plugin' => $file,
		'new_version' => $info['version'],
		'url' => 'https://github.com/shibainugen/isha-map',
		'package' => $info['zip'],
		'icons' => array(),
		'banners' => array(),
		'tested' => get_bloginfo('version'),
	);
	if (version_compare($info['version'], AOBA_ISHA_MAP_VER, '>')) {
		if (!isset($t->response) || !is_array($t->response)) $t->response = array();
		$t->response[$file] = $item;
	} else {
		if (!isset($t->no_update) || !is_array($t->no_update)) $t->no_update = array();
		$t->no_update[$file] = $item;
	}
	return $t;
});

// このプラグインは自動更新をオンにしておく（WordPress が1日2回、自分で更新する）
add_filter('auto_update_plugin', function ($update, $item) {
	if (isset($item->plugin) && $item->plugin === plugin_basename(AOBA_ISHA_MAP_FILE)) return true;
	return $update;
}, 10, 2);

// 「詳細を表示」で空の画面にならないように
add_filter('plugins_api', function ($res, $action, $args) {
	if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== 'aoba-isha-map') return $res;
	$info = aim_remote_version();
	return (object) array(
		'name' => '全国お医者さんマップ',
		'slug' => 'aoba-isha-map',
		'version' => $info ? $info['version'] : AOBA_ISHA_MAP_VER,
		'author' => 'REグループ',
		'homepage' => 'https://isha.re-kaitori.jp/',
		'sections' => array('description' => '全国47都道府県の病院・クリニックを地図・駅・診療科から探せるサイト一式。', 'changelog' => $info && !empty($info['notes']) ? esc_html($info['notes']) : ''),
		'download_link' => $info ? $info['zip'] : '',
	);
}, 10, 3);

/**
 * 管理者が開くと、その場で最新版に更新する入口：/wp-admin/admin-post.php?action=aim_update_now
 * （ログインした管理者だけ。WordPress の通常の更新処理をそのまま使う）
 */
add_action('admin_post_aim_update_now', function () {
	if (!current_user_can('update_plugins')) wp_die('権限がありません。');
	delete_site_transient('update_plugins');
	wp_update_plugins();
	$file = plugin_basename(AOBA_ISHA_MAP_FILE);
	$t = get_site_transient('update_plugins');
	echo '<!doctype html><meta charset="utf-8"><title>お医者さんマップの更新</title><body style="font:16px/1.7 sans-serif;max-width:720px;margin:2em auto">';
	if (empty($t->response[$file])) {
		echo '<p id="aim-result">AIM_UP_TO_DATE：すでに最新版（' . esc_html(AOBA_ISHA_MAP_VER) . '）です。</p>';
		echo '<p><a href="' . esc_url(admin_url()) . '">管理画面へ戻る</a></p>';
		exit;
	}
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	$was_active = is_plugin_active($file);
	$up = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
	$ok = $up->upgrade($file);
	if ($was_active && !is_plugin_active($file)) activate_plugin($file);
	$new = get_file_data(WP_PLUGIN_DIR . '/' . $file, array('Version' => 'Version'));
	if ($ok && !is_wp_error($ok)) echo '<p id="aim-result">AIM_UPDATED：' . esc_html($new['Version']) . ' に更新しました。</p>';
	else echo '<p id="aim-result">AIM_FAILED：更新できませんでした。' . (is_wp_error($ok) ? esc_html($ok->get_error_message()) : '') . '</p>';
	echo '<p><a href="' . esc_url(admin_url()) . '">管理画面へ戻る</a>（ページの更新処理は管理画面を開くと進みます）</p>';
	exit;
});
