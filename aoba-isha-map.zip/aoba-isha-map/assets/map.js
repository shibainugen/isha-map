/* 全国お医者さんマップ（WordPressプラグイン版） v2 */
(() => {
if (!document.getElementById("aim-map")) return;
const DAYS = ["日", "月", "火", "水", "木", "金", "土"];
const ORDER = ["月", "火", "水", "木", "金", "土", "日", "祝"];
const AOBA = [35.5400, 139.4950]; // 掲載エリアのまんなかあたり
const GROUPS = {};
const CFG = window.AOBA_ISHA_MAP || {};
// 医療機関のデータは地図の区画（約2.8km四方）ごとのファイルに分けてあり、見えている範囲の区画だけを読む
const TL = CFG.tiles || { tiles: [], base: "", ver: 0, geos: [] };
const AREAS = TL.tiles.map((t) => { const k = Array.isArray(t) ? t[0] : t.split(":")[0], n = Array.isArray(t) ? t[1] : +t.split(":")[1], ij = k.split("_").map(Number); return { key: k, n: n, bbox: [ij[0] * 0.025, ij[1] * 0.03, (ij[0] + 1) * 0.025, (ij[1] + 1) * 0.03], url: TL.base.replace(/^https?:/, "") + k + ".json?v=" + TL.ver }; });
const GEOS = TL.geos || [];
let facilities = [], origin = null, originLabel = "", markers = new Map(), hereMarker = null;
const areaState = new Map(); // key -> Promise（読み込み中・読み込み済み）
let loadedAreas = 0;

// スマホでは1本指でページをスクロールできるようにし、地図は2本指で動かす
const TOUCH = L.Browser.mobile || (window.matchMedia && matchMedia("(pointer: coarse)").matches);
const map = L.map("aim-map", {
  zoomControl: true, preferCanvas: true,
  renderer: L.canvas({ tolerance: TOUCH ? 10 : 3 }), // 指でも病院の印を押しやすく
  gestureHandling: !!(TOUCH && window.leafletGestureHandling),
  gestureHandlingOptions: { text: { touch: "地図は2本指で動かせます", scroll: "Ctrlを押しながらスクロールで拡大・縮小", scrollMac: "⌘を押しながらスクロールで拡大・縮小" }, duration: 1200 },
}).setView(AOBA, 13);
L.tileLayer("https://cyberjapandata.gsi.go.jp/xyz/std/{z}/{x}/{y}.png", {
  maxZoom: 18, attribution: '<a href="https://maps.gsi.go.jp/development/ichiran.html" target="_blank" rel="noopener">地理院タイル</a>'
}).addTo(map);

const $ = (id) => document.getElementById("aim-" + id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function distKm(a, b) {
  const R = 6371, r = Math.PI / 180;
  const dLat = (b[0] - a[0]) * r, dLng = (b[1] - a[1]) * r;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
function fmtDist(km) { return km < 1 ? Math.round(km * 1000) + " m" : km.toFixed(1) + " km"; }
function walkMin(km) { return Math.max(1, Math.round(km * 1000 / 80)); } // 不動産表示と同じ 80m/分

const toMin = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };

// 日本の祝日（振替休日・国民の休日を含む）
const holCache = {};
function holidaysOf(y) {
  if (holCache[y]) return holCache[y];
  const set = new Set(), key = (m, d) => `${m}-${d}`;
  const nthMon = (m, n) => { const w = new Date(y, m - 1, 1).getDay(); return 1 + ((8 - w) % 7) + (n - 1) * 7; };
  const shun = Math.floor(20.8431 + 0.242194 * (y - 1980) - Math.floor((y - 1980) / 4));
  const shu = Math.floor(23.2488 + 0.242194 * (y - 1980) - Math.floor((y - 1980) / 4));
  [[1, 1], [1, nthMon(1, 2)], [2, 11], [2, 23], [3, shun], [4, 29], [5, 3], [5, 4], [5, 5], [7, nthMon(7, 3)],
   [8, 11], [9, nthMon(9, 3)], [9, shu], [10, nthMon(10, 2)], [11, 3], [11, 23]].forEach(([m, d]) => set.add(key(m, d)));
  const base = [...set];
  base.forEach((k) => { // 振替休日
    const [m, d] = k.split("-").map(Number);
    if (new Date(y, m - 1, d).getDay() === 0) {
      const t = new Date(y, m - 1, d + 1);
      while (set.has(key(t.getMonth() + 1, t.getDate()))) t.setDate(t.getDate() + 1);
      set.add(key(t.getMonth() + 1, t.getDate()));
    }
  });
  for (let t = new Date(y, 0, 2); t.getFullYear() === y; t.setDate(t.getDate() + 1)) { // 国民の休日
    const p = new Date(t), n = new Date(t); p.setDate(p.getDate() - 1); n.setDate(n.getDate() + 1);
    if (t.getDay() !== 0 && !set.has(key(t.getMonth() + 1, t.getDate())) &&
        set.has(key(p.getMonth() + 1, p.getDate())) && set.has(key(n.getMonth() + 1, n.getDate()))) set.add(key(t.getMonth() + 1, t.getDate()));
  }
  return (holCache[y] = set);
}
const isHoliday = (d) => holidaysOf(d.getFullYear()).has(`${d.getMonth() + 1}-${d.getDate()}`);
const todayKey = (now = new Date()) => (isHoliday(now) ? "祝" : DAYS[now.getDay()]);

function openState(f, now = new Date()) {
  if (!f.hours || Object.keys(f.hours).length === 0) return null; // 情報なし
  const hol = isHoliday(now);
  if (hol && f.hol === "ask") return { open: false, text: "祝日の診療は要確認" };
  const slots = hol ? (f.hours["祝"] || []) : f.hours[DAYS[now.getDay()]];
  if (!slots || !slots.length) return { open: false, text: hol ? "祝日休診" : "本日休診" };
  if (slots.some((s) => s[0] === "?")) return { open: false, text: "本日の時間は要確認" }; // 届け出の開始時刻がおかしい所
  const m = now.getHours() * 60 + now.getMinutes();
  for (const s of slots) {
    const [a, b] = s.split("-");
    if (m >= toMin(a) && m < toMin(b)) return { open: true, text: `診療時間内・目安（${b}まで）` };
  }
  const next = slots.find((s) => toMin(s.split("-")[0]) > m);
  return { open: false, text: next ? `本日 ${next.split("-")[0]} から` : "本日の診療は終了" };
}

function hoursTable(f) {
  if (!f.hours || !Object.values(f.hours).some((s) => s && s.length)) return "<p>診療時間の情報はありません。医療機関にお問い合わせください。</p>";
  const today = todayKey();
  return "<table>" + ORDER.map((d) => {
    const s = f.hours[d];
    let v = s && s.length ? s.map((x) => (x[0] === "?" ? "開始時刻は要確認〜" + esc(x.slice(2)) : esc(x))).join("、") : "休診";
    if (d === "祝" && !(s && s.length)) v = f.hol === "ask" ? "診療あり／時間は要確認" : "休診";
    return `<tr class="${d === today ? "today" : ""}"><th>${d}</th><td>${v}</td></tr>`;
  }).join("") + "</table>";
}

// 「小児」の付く診療科（小児科・小児皮膚科など）を届け出ている所
function isKids(f) { return (f.deps || []).some((d) => d.indexOf("小児") !== -1); }

// 一覧は最初に PAGE 件だけ出し、残りは「もっと見る」で足していく（ページを軽くするため）
const PAGE = 30;
const MAX = 100; // 一覧と地図の印は、近い順にこの件数まで（たくさん描くと端末が重くなるため）
const MIN_LOAD_ZOOM = 13; // これより引いた地図では、新しいエリアのデータを読まない
let lastRows = [], shown = 0;
function itemHtml({ f, d, st }) { return `
    <li class="aim-item" tabindex="0" data-id="${esc(f.id)}">
      <h3>${esc(f.short || f.name)}</h3>${f.short ? `<div class="aim-formal">${esc(f.name)}</div>` : ""}
      <span class="aim-dist">${d == null ? "" : fmtDist(d) + `<br><small>徒歩${walkMin(d)}分</small>`}</span>
      <div class="aim-meta">${esc(f.addr)}${f.tel ? "　☎ " + esc(f.tel) : ""}</div>
      <div class="aim-badges">
        ${st ? `<span class="aim-pill ${st.open ? "open" : "closed"}" title="届け出の時間から判断しています。受診前にお電話で確認を">${esc(st.text)}</span>` : ""}
        <span class="aim-pill kind">${esc(f.kind)}</span>
        ${isKids(f) ? `<span class="aim-pill kids">👶 子どもOK</span>` : ""}
        ${(f.deps || []).slice(0, 6).map((x) => `<span class="aim-pill">${esc(x)}</span>`).join("")}
      </div>
      <div class="aim-hours" hidden>${hoursTable(f)}</div>
      <div class="aim-links" hidden>
        ${f.tel ? `<a href="tel:${esc(f.tel.replace(/[^0-9+]/g, ""))}">電話する</a>` : ""}
        ${f.url ? `<a href="${esc(f.url)}" target="_blank" rel="noopener">ホームページ</a>` : ""}
        <a href="https://www.google.com/maps/dir/?api=1&destination=${f.lat},${f.lng}" target="_blank" rel="noopener">道順を見る</a>
        <a href="/clinic/${esc(f.id)}/">くわしく見る</a>
      </div>
    </li>`; }
function showMore() {
  const more = $("list").querySelector(".aim-more"); if (more) more.remove();
  const next = lastRows.slice(shown, shown + PAGE);
  $("list").insertAdjacentHTML("beforeend", next.map(itemHtml).join(""));
  shown += next.length;
  const rest = lastRows.length - shown;
  if (rest > 0) $("list").insertAdjacentHTML("beforeend", `<li class="aim-more"><button type="button" class="aim-ghost">もっと見る（あと${rest}件）</button></li>`);
}

function render() {
  const dept = $("dept").value, onlyOpen = $("open").checked, onlyKids = $("kids") && $("kids").checked;
  const re = dept ? GROUPS[dept] : null;
  let rows = facilities.filter((f) => !re || (f.deps || []).some((x) => re.test(x)));
  // 起点（現在地・駅など）がなければ、地図の真ん中から近い順にする
  const c = origin || (() => { const ll = map.getCenter(); return [ll.lat, ll.lng]; })();
  rows = rows.map((f) => ({ f, k: distKm(c, [f.lat, f.lng]), st: openState(f) }));
  if (onlyOpen) rows = rows.filter((r) => r.st && r.st.open);
  if (onlyKids) rows = rows.filter((r) => isKids(r.f));
  rows.sort((a, b) => a.k - b.k);
  const total = rows.length;
  rows = rows.slice(0, MAX).map((r) => ({ f: r.f, d: origin ? r.k : null, st: r.st }));
  // 地図の印も、一覧に出す分だけにする
  markers.forEach((m) => { m.closeTooltip(); if (map.hasLayer(m)) m.remove(); });
  rows.forEach(({ f, st }) => {
    const m = markers.get(f.id);
    if (!m) return;
    m.setStyle({ opacity: 1, fillOpacity: .85, fillColor: st && st.open ? "#1d7a46" : "#1f6f8b" });
    m.addTo(map);
  });
  lastRows = rows; shown = 0;
  const far = !loadedAreas && map.getZoom() < MIN_LOAD_ZOOM;
  $("list").innerHTML = rows.length ? "" : `<li class="aim-item"><div class="aim-meta">${far ? "地図を拡大すると、その付近の医療機関を表示します。" : "条件に合う医療機関がありません。"}</div></li>`;
  showMore();
  const n = rows.length, cut = total > n ? `（${MAX}件まで表示）` : "";
  $("status").textContent = origin
    ? `${originLabel}から近い順に ${n.toLocaleString()} 件${cut}`
    : `地図の真ん中から近い ${n.toLocaleString()} 件${cut} ― 現在地か地名を入れると、そこから近い順に並びます。`;
}

// ---- エリアごとの読み込み：地図に見えている範囲にかかるエリアだけ読む ----
function addFacilities(list) {
  list.forEach((f) => {
    facilities.push(f);
    const m = L.circleMarker([f.lat, f.lng], { radius: f.kind === "病院" ? 9 : 7, color: "#fff", weight: 2, fillColor: "#1f6f8b", fillOpacity: .85, bubblingMouseEvents: false })
      .bindTooltip(f.short || f.name);
    // 名前の吹き出しは一度に1つだけ
    m.on("tooltipopen", () => markers.forEach((o) => { if (o !== m) o.closeTooltip(); }));
    m.on("click", (e) => { L.DomEvent.stopPropagation(e); lastMarkerTap = Date.now(); openItem(f.id, false); });
    markers.set(f.id, m);
  });
}
function loadArea(a) {
  if (!areaState.has(a.key)) {
    areaState.set(a.key, fetch(a.url).then((r) => { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then((d) => { addFacilities(d.facilities || []); loadedAreas++; return true; })
      .catch((e) => { areaState.delete(a.key); throw e; }));
    return areaState.get(a.key);
  }
  return areaState.get(a.key).then(() => false);
}
// bounds にかかるエリアをすべて読む。新しく読んだものがあれば true
function ensureAreas(bounds) {
  const need = AREAS.filter((a) => bounds.intersects(L.latLngBounds([a.bbox[0], a.bbox[1]], [a.bbox[2], a.bbox[3]])));
  return Promise.all(need.map(loadArea)).then((r) => r.some(Boolean));
}
const nearBounds = (latlng, m = 6000) => L.latLng(latlng).toBounds(m); // m: 四角の一辺（m）
let moveTimer = null, keepList = false; // keepList: 一覧から選んで地図を動かしたときは並べ直さない
map.on("moveend", () => {
  clearTimeout(moveTimer);
  moveTimer = setTimeout(() => {
    // 引いた地図ではデータを読み足さない（広い範囲を一度に読むと重いため）
    const load = map.getZoom() >= MIN_LOAD_ZOOM ? ensureAreas(map.getBounds().pad(0.1)) : Promise.resolve(false);
    const keep = keepList; keepList = false;
    load.then((added) => { if (added || (!origin && !keep)) render(); })
      .catch(() => { $("status").textContent = "医療機関データの一部を読み込めませんでした。通信状況を確認してください。"; });
  }, 250);
});

function openItem(id, pan) {
  document.querySelectorAll(".aim-item.active").forEach((el) => {
    el.classList.remove("active"); el.querySelectorAll(".aim-hours,.aim-links").forEach((x) => (x.hidden = true));
  });
  let el = document.querySelector(`.aim-item[data-id="${CSS.escape(id)}"]`);
  if (!el) {
    // まだ一覧に出していない医療機関なら、そこまで「もっと見る」を進める
    const i = lastRows.findIndex((r) => r.f.id === id);
    while (i >= 0 && i >= shown && shown < lastRows.length) showMore();
    el = document.querySelector(`.aim-item[data-id="${CSS.escape(id)}"]`);
  }
  if (el) {
    el.classList.add("active"); el.querySelectorAll(".aim-hours,.aim-links").forEach((x) => (x.hidden = false));
    el.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }
  const f = facilities.find((x) => x.id === id);
  if (f && pan) { keepList = true; map.setView([f.lat, f.lng], Math.max(map.getZoom(), 16)); }
}

async function setOrigin(latlng, label) {
  origin = latlng; originLabel = label;
  if (hereMarker) hereMarker.remove();
  hereMarker = L.marker(latlng, { icon: L.divIcon({ className: "", html: '<div class="aim-here"></div>', iconSize: [18, 18] }), zIndexOffset: 1000 })
    .addTo(map).bindTooltip(label);
  map.setView(latlng, 15);
  // 近い順に並べる前に、その周りのエリアを読んでおく（境目の向こうの医療機関も入れるため）
  // まず近く（約2km四方）だけ読み、近い順の件数に足りなければ広げる（都心は近くだけで足りるので軽くなる）
  try {
    await ensureAreas(nearBounds(latlng, 2000));
    const count = (km) => facilities.filter((f) => distKm(latlng, [f.lat, f.lng]) < km).length;
    if (count(1) < MAX) await ensureAreas(nearBounds(latlng, 6000));
    if (count(3) < 30) await ensureAreas(nearBounds(latlng, 20000)); // 山あいなど医療機関が少ない所は、もっと広く
  } catch { /* 読めた分で並べる */ }
  if (origin !== latlng) return; // 待っている間に別の場所が選ばれた
  render();
  $("list").scrollTop = 0;
}

$("list").addEventListener("click", (e) => { if (e.target.closest(".aim-more button")) { showMore(); return; } const li = e.target.closest(".aim-item[data-id]"); if (li && !e.target.closest("a")) openItem(li.dataset.id, true); });
$("list").addEventListener("keydown", (e) => { if (e.key === "Enter") { const li = e.target.closest(".aim-item[data-id]"); if (li) openItem(li.dataset.id, true); } });
$("dept").addEventListener("change", render);
$("open").addEventListener("change", render);
if ($("kids")) $("kids").addEventListener("change", render);
// 何もない所を押したときだけ、そこを起点にする（病院の印を押したときは動かさない）
let lastMarkerTap = 0;
map.on("click", (e) => {
  if (Date.now() - lastMarkerTap < 400) return;
  // 印のすぐ近く（指の太さぶん）を押したときも、病院を押したことにする
  const p = e.containerPoint; let best = null, bd = TOUCH ? 22 : 10;
  markers.forEach((m, id) => { if (!map.hasLayer(m)) return; const d = map.latLngToContainerPoint(m.getLatLng()).distanceTo(p); if (d < bd) { bd = d; best = id; } });
  if (best) { openItem(best, false); return; }
  setOrigin([e.latlng.lat, e.latlng.lng], "タップした場所");
});

// 現在地・地名で探したあと、地図が画面の上に来るまで下げる（スマホで押したあと手で下げなくて済むように）
function showMap() {
  const el = document.getElementById("aim-map"); if (!el) return;
  if (document.activeElement && document.activeElement.id === "aim-q") document.activeElement.blur(); // キーボードを閉じる
  const hd = document.querySelector(".aim-hd"), ab = document.getElementById("wpadminbar");
  const off = (hd ? hd.getBoundingClientRect().height : 0) + (ab && getComputedStyle(ab).position === "fixed" ? ab.offsetHeight : 0) + 8;
  const y = el.getBoundingClientRect().top + window.scrollY - off;
  if (Math.abs(window.scrollY - y) > 40) window.scrollTo({ top: Math.max(0, y), behavior: "smooth" });
}

$("locate").addEventListener("click", () => {
  if (!navigator.geolocation) { $("status").textContent = "この端末では現在地を取得できません。地名で探してください。"; return; }
  $("status").textContent = "現在地を確認しています…";
  navigator.geolocation.getCurrentPosition(
    (p) => { setOrigin([p.coords.latitude, p.coords.longitude], "現在地"); showMap(); },
    () => { $("status").textContent = "現在地を取得できませんでした。位置情報の許可を確認するか、地名で探してください。"; },
    { enableHighAccuracy: true, timeout: 10000 }
  );
});

$("search").addEventListener("submit", async (e) => {
  e.preventDefault();
  const q = $("q").value.trim();
  if (!q) return;
  $("status").textContent = "場所を探しています…";
  try {
    // 掲載エリアの地名を頭に付けて順に試す（エリアの一覧は設定から）
    const geos = GEOS;
    const short = (g) => g.replace(/^(東京都|神奈川県|横浜市|川崎市)/, "");
    const named = geos.some((g) => q.includes(short(g))) || /横浜|川崎|相模原/.test(q);
    const tries = named ? [q] : [q, ...geos.map((g) => g + q)]; // まず地名だけで探し、見つからなければ掲載エリアの市区名を頭に付けて探す
    const inArea = (t) => geos.some((g) => t.includes(g.replace(/^(東京都|神奈川県)/, "")));
    let hits = [];
    for (const query of tries) {
      const res = await fetch("https://msearch.gsi.go.jp/address-search/AddressSearch?q=" + encodeURIComponent(query));
      hits = (await res.json()).filter((h) => inArea(h.properties.title));
      if (hits.length) break;
    }
    if (!hits.length) { $("status").textContent = `「${q}」が見つかりませんでした。町名と丁目で試してください。`; return; }
    const [lng, lat] = hits[0].geometry.coordinates;
    setOrigin([lat, lng], `「${hits[0].properties.title}」`); showMap();
  } catch {
    $("status").textContent = "場所の検索に失敗しました。通信状況を確認してもう一度お試しください。";
  }
});

// ---- 最初の表示 ----
$("asof").textContent = CFG.asof || "-";
if (CFG.telAsof && $("telasof")) $("telasof").textContent = CFG.telAsof;
// 診療科は「診療科から探す」と同じまとまりで選ぶ（似た名前の科をひとつにまとめる）。件数は掲載エリア全体の数
{
  const G = CFG.groups || { main: [], extra: [] };
  const addOpts = (list, parent) => list.forEach((g) => {
    GROUPS["g:" + g.slug] = new RegExp(g.re, "u");
    if (g.n) parent.insertAdjacentHTML("beforeend", `<option value="g:${esc(g.slug)}">${esc(g.label)}（${g.n}）</option>`);
  });
  addOpts(G.main, $("dept"));
  if (G.extra.length) {
    const og = document.createElement("optgroup"); og.label = "そのほかの科"; $("dept").appendChild(og);
    addOpts(G.extra, og);
  }
  const P = CFG.preset || {};
  if (P.group && GROUPS["g:" + P.group.slug]) $("dept").value = "g:" + P.group.slug;
  // 「診療科から探す」から来たとき（?ka=naika）：その科にしぼって、現在地から近い順に
  const KA = new URLSearchParams(location.search).get("ka");
  if (KA && GROUPS["g:" + KA]) {
    $("dept").value = "g:" + KA;
    ensureAreas(map.getBounds()).then(render).catch(() => {});
    $("locate").click();
    showMap();
  }
  else if (P.origin) {
    const ll = [P.origin.lat, P.origin.lng];
    // ページの組み立て中は地図の大きさが確定していないことがあるので、読み込み後に測り直して駅を真ん中に戻す
    setOrigin(ll, P.origin.label).then(() => { map.invalidateSize(); if (origin === ll) map.setView(ll, map.getZoom()); });
  }
  else ensureAreas(map.getBounds()).then(render) // 最初は見えている範囲だけ（軽くするため）
    .catch(() => { $("status").textContent = "医療機関データを読み込めませんでした。通信状況を確認して、ページを開き直してください。"; });
}
})();
