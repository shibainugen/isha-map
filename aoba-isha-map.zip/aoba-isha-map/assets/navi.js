/* 症状ナビ：症状から「何科に行けばよいか」の目安を案内する（診断はしない） */
(() => {
const root = document.getElementById("ain");
if (!root) return;
const CFG = window.AOBA_ISHA_NAVI || { pages: {}, emergency: "" };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// 診療科の表示名
const DEPT = {
  naika: "内科", shonika: "小児科", hifuka: "皮膚科", jibika: "耳鼻咽喉科", ganka: "眼科", seikei: "整形外科",
  shokaki: "消化器内科・胃腸内科", junkanki: "循環器内科", kokyuki: "呼吸器内科", tonyobyo: "糖尿病・内分泌内科",
  allergy: "アレルギー科", shinryonaika: "心療内科・精神科", fujinka: "産婦人科・婦人科", hinyokika: "泌尿器科",
  noshinkei: "脳神経外科・脳神経内科", keisei: "形成外科", rihabiri: "リハビリテーション科", rheumatism: "リウマチ科",
};

// 緊急度：call = 119、ask = 迷ったら相談、
const URGENT = {
  call: { cls: "call", title: "すぐに119番へ", body: "命に関わるおそれがあります。迷わず119番に電話してください。" },
  ask: { cls: "ask", title: "今すぐ受診すべきか、まず電話で相談を" },
};

/*
 各症状： q = 表示名, red = 当てはまれば119（call）、warn = 当てはまれば相談（ask）、
 choices = 最後の質問（どれに近い？）→ 科の候補
*/
const ADULT = [
  { id: "fever", q: "熱・かぜっぽい（せき・のど・鼻水）",
    red: ["息が苦しくて会話ができない", "唇や顔色が紫っぽい・青白い", "呼びかけへの反応が鈍い・意識がおかしい"],
    warn: ["39度以上の熱が続いてぐったりしている", "水分がほとんど取れない"],
    choices: [
      { a: "熱・だるさ・のどや鼻もある（ふつうのかぜ症状）", d: ["naika"], note: "まずは内科へ。発熱外来の有無や受診方法は、事前に電話で確認するのが確実です。" },
      { a: "のどの痛み・鼻づまり・耳の痛みが中心", d: ["jibika", "naika"], note: "のど・鼻・耳の症状が強いときは耳鼻咽喉科が向いています。" },
      { a: "熱はないが、せきが2〜3週間以上続いている", d: ["kokyuki", "naika"], note: "長引くせきは呼吸器内科で詳しく調べてもらえます。" },
    ] },
  { id: "head", q: "頭が痛い",
    red: ["今までで一番ひどい頭痛が突然起きた", "手足のしびれ・動かしにくさ、ろれつが回らない", "頭を強く打ったあとで、吐き気や意識がおかしい"],
    warn: ["高い熱があり、首を前に曲げると痛い・首が硬い"],
    choices: [
      { a: "ときどき起きる頭痛・片頭痛・肩こりからの頭痛", d: ["noshinkei", "naika"], note: "頭痛を詳しく診てもらうなら脳神経外科・脳神経内科。軽いものは内科でも相談できます。" },
      { a: "かぜ症状と一緒の頭痛", d: ["naika"], note: "かぜに伴う頭痛は内科へ。" },
    ] },
  { id: "dizzy", q: "めまい・ふらつき",
    red: ["手足のまひ・しびれ、ろれつが回らない、顔がゆがむ", "激しい頭痛と一緒にめまいがある", "立っていられず、意識が遠のく"],
    warn: ["動けないほどのめまいで、吐き気が止まらない"],
    choices: [
      { a: "耳鳴り・聞こえにくさがある／頭を動かすとグルグル回る", d: ["jibika"], note: "耳が原因のめまいは多く、耳鼻咽喉科が向いています。" },
      { a: "立ちくらみ・フワフワする", d: ["naika", "junkanki"], note: "貧血や血圧が関係することもあるので、まず内科へ。" },
      { a: "よくわからない", d: ["naika", "noshinkei"], note: "まず内科で相談し、必要なら専門の科を紹介してもらいましょう。" },
    ] },
  { id: "chest", q: "胸の痛み・動悸・息切れ",
    red: ["胸が締めつけられる・押される痛みが数分以上続く", "冷や汗・吐き気を伴う胸の痛み", "息が苦しくて横になれない・会話ができない"],
    warn: ["脈がとても速い・とても遅い状態が続いている"],
    choices: [
      { a: "動悸・脈が乱れる・坂道で息切れ", d: ["junkanki"], note: "心臓や血管の症状は循環器内科へ。" },
      { a: "せき・たんがあり、息が苦しい", d: ["kokyuki", "naika"], note: "肺や気管支の症状は呼吸器内科へ。" },
      { a: "体を動かすと胸やあばらが痛む", d: ["seikei", "naika"], note: "筋肉や骨の痛みのこともあります。迷ったら内科へ。" },
    ] },
  { id: "stomach", q: "おなかが痛い・下痢・吐き気",
    red: ["血を吐いた、または真っ黒な便・大量の血便が出た", "激しい痛みで動けない・おなかが板のように硬い"],
    warn: ["吐き続けて水分が取れない", "痛みがどんどん強くなっている"],
    choices: [
      { a: "胃のむかつき・胸やけ・下痢・便秘", d: ["shokaki", "naika"], note: "胃腸の症状は消化器内科・胃腸内科へ。胃カメラ・大腸カメラもここで相談できます。" },
      { a: "下腹部の痛み（女性で、生理や妊娠が関係しそう）", d: ["fujinka", "naika"], note: "生理や妊娠に関係しそうなら産婦人科・婦人科へ。" },
      { a: "おしっこのときに痛い・背中や脇腹が痛い", d: ["hinyokika", "naika"], note: "尿路の病気のことがあるので泌尿器科が向いています。" },
    ] },
  { id: "skin", q: "皮膚（発疹・かゆみ・できもの）",
    red: ["全身にじんましんが出て、息苦しい・唇やまぶたが腫れている"],
    warn: ["発疹とともに高い熱が出て、ぐったりしている"],
    choices: [
      { a: "湿疹・かぶれ・かゆみ・ニキビ・水虫", d: ["hifuka"], note: "皮膚のトラブルは皮膚科へ。" },
      { a: "粉瘤（できもの）・巻き爪・傷あとが気になる", d: ["keisei", "hifuka"], note: "できものを取る・傷を治すなら形成外科も向いています。" },
      { a: "花粉や食べ物などのアレルギーが疑わしい", d: ["allergy", "hifuka"], note: "アレルギー全般はアレルギー科で相談できます。" },
    ] },
  { id: "injury", q: "けが・やけど・骨や関節・腰の痛み",
    red: ["頭を強く打って、意識がおかしい・何度も吐く", "出血が止まらない", "手足が明らかに変な向きに曲がっている"],
    warn: ["広い範囲のやけど・顔や関節のやけど", "強い痛みで歩けない"],
    choices: [
      { a: "ねんざ・骨折かも・腰痛・肩こり・ひざの痛み", d: ["seikei"], note: "骨・関節・筋肉は整形外科へ。" },
      { a: "切り傷・やけど・顔のけが", d: ["keisei", "hifuka"], note: "傷をきれいに治すなら形成外科、軽いやけどは皮膚科でも診てもらえます。" },
      { a: "朝の手指のこわばり・複数の関節が腫れる", d: ["rheumatism", "seikei"], note: "関節リウマチが心配ならリウマチ科へ。" },
    ] },
  { id: "eye", q: "目",
    red: [],
    warn: ["急に見えなくなった・視野が欠けた", "薬品が目に入った（まず水で15分以上洗い流す）", "目を強くぶつけた"],
    choices: [
      { a: "かゆみ・充血・目やに・ものもらい", d: ["ganka"], note: "目の症状は眼科へ。" },
      { a: "見えにくい・コンタクトの相談", d: ["ganka"], note: "視力やコンタクトレンズも眼科で相談できます。" },
    ] },
  { id: "ent", q: "耳・鼻・のど",
    red: ["のどが腫れて息がしにくい・つばが飲み込めない"],
    warn: ["急に片方の耳が聞こえなくなった"],
    choices: [
      { a: "耳の痛み・聞こえにくい・耳鳴り", d: ["jibika"], note: "耳の症状は耳鼻咽喉科へ。急な難聴は早めの受診が大切です。" },
      { a: "鼻水・鼻づまり・花粉症", d: ["jibika", "allergy"], note: "鼻の症状は耳鼻咽喉科、アレルギー全般ならアレルギー科も。" },
      { a: "のどの痛み・声がかれる", d: ["jibika", "naika"], note: "のどの症状は耳鼻咽喉科、かぜ症状と一緒なら内科でも。" },
    ] },
  { id: "urine", q: "おしっこの悩み",
    red: [],
    warn: ["おしっこがまったく出ず、おなかが張って苦しい", "高い熱と背中の痛みがある"],
    choices: [
      { a: "トイレが近い・排尿時の痛み・残尿感・尿もれ", d: ["hinyokika"], note: "排尿の悩みは泌尿器科へ。" },
      { a: "血尿が出た", d: ["hinyokika", "naika"], note: "血尿は泌尿器科で調べてもらいましょう。" },
    ] },
  { id: "women", q: "生理・妊娠・女性の体",
    red: ["妊娠中で、大量の出血や激しいおなかの痛みがある"],
    warn: ["妊娠の可能性があり、強い腹痛や出血がある"],
    choices: [
      { a: "生理痛・生理不順・更年期・婦人科検診", d: ["fujinka"], note: "婦人科で相談できます。" },
      { a: "妊娠したかもしれない・妊娠中の相談", d: ["fujinka"], note: "産婦人科へ。かかりつけがあればまずそちらへ連絡を。" },
    ] },
  { id: "mind", q: "心の不調・眠れない",
    red: ["死にたい気持ちが強く、今にも行動してしまいそう"],
    warn: [],
    choices: [
      { a: "気分の落ち込み・不安・眠れない・ストレスで体調が悪い", d: ["shinryonaika"], note: "心療内科・精神科で相談できます。初めての受診は予約制のところが多いので、まず電話で確認を。" },
    ],
    mind: true },
  { id: "checkup", q: "健康診断で引っかかった（血圧・血糖・コレステロールなど）",
    red: [], warn: [],
    choices: [
      { a: "血糖値・HbA1c・甲状腺", d: ["tonyobyo", "naika"], note: "糖尿病・内分泌内科で詳しく診てもらえます。まず内科でも大丈夫です。" },
      { a: "血圧・心電図", d: ["junkanki", "naika"], note: "循環器内科へ。" },
      { a: "コレステロール・肝機能・そのほか", d: ["naika"], note: "まずは内科で相談し、必要なら専門の科へ。" },
    ] },
];

const CHILD = [
  { id: "cfever", q: "熱がある",
    red: ["呼びかけに反応が鈍い・ぐったりして意識がおかしい", "けいれんが5分以上続く・繰り返す", "唇が紫色で息が苦しそう"],
    warn: ["生後3か月未満で38度以上の熱がある", "水分が取れず、半日以上おしっこが出ていない", "ぐったりしていて機嫌がとても悪い"],
    choices: [
      { a: "熱・せき・鼻水（かぜっぽい）", d: ["shonika"], note: "子どもの病気はまず小児科へ。" },
      { a: "耳を痛がる・耳だれが出る", d: ["jibika", "shonika"], note: "中耳炎が疑われるときは耳鼻咽喉科へ。" },
    ] },
  { id: "ccough", q: "せき・ゼーゼーする",
    red: ["息が苦しくて肩で息をしている・唇が紫色", "急にむせ込んで、何かを詰まらせたかもしれない"],
    warn: ["ゼーゼー・ヒューヒューして眠れない"],
    choices: [
      { a: "せき・鼻水・ゼーゼー", d: ["shonika"], note: "小児科へ。ぜんそくの相談もできます。" },
    ] },
  { id: "cstomach", q: "おなかが痛い・吐く・下痢",
    red: ["ぐったりして反応が鈍い"],
    warn: ["吐き続けて水分が取れない・おしっこが出ていない", "便に血が混じる・いちごジャムのような便", "激しく泣き続けて、おなかを痛がる"],
    choices: [
      { a: "吐き気・下痢・腹痛", d: ["shonika"], note: "小児科へ。脱水に気をつけて、少しずつ水分を。" },
    ] },
  { id: "cskin", q: "発疹・皮膚のトラブル",
    red: ["全身にじんましんが出て、息苦しい・唇が腫れている"],
    warn: ["発疹と高い熱があり、ぐったりしている"],
    choices: [
      { a: "熱と一緒に発疹が出た", d: ["shonika"], note: "感染症のことがあるので小児科へ。" },
      { a: "湿疹・あせも・とびひ・かぶれ", d: ["hifuka", "shonika"], note: "皮膚だけの症状なら皮膚科（小児皮膚科）へ。" },
    ] },
  { id: "cinjury", q: "けが・やけど・誤飲",
    red: ["頭を打って意識がおかしい・何度も吐く", "出血が止まらない", "ボタン電池・強い薬品を飲み込んだ"],
    warn: ["タバコ・薬・洗剤などを飲み込んだかもしれない（すぐ #8000 に相談）"],
    choices: [
      { a: "ねんざ・骨折かも・手足を痛がる", d: ["seikei"], note: "骨や関節のけがは整形外科へ。" },
      { a: "切り傷・やけど", d: ["keisei", "hifuka"], note: "傷をきれいに治すなら形成外科、軽いやけどは皮膚科でも。" },
    ] },
  { id: "ceye", q: "目・耳・鼻",
    red: [], warn: ["目に薬品が入った（まず水で15分以上洗い流す）"],
    choices: [
      { a: "目やに・充血・ものもらい", d: ["ganka", "shonika"], note: "目の症状は眼科へ。" },
      { a: "耳の痛み・鼻水が長引く", d: ["jibika", "shonika"], note: "耳鼻咽喉科へ。" },
    ] },
];

let state = { who: null, item: null };

function deptLinks(ds) {
  return ds.map((d, i) => {
    const u = CFG.pages[d];
    const label = esc(DEPT[d] || d);
    return `<li class="${i === 0 ? "main" : ""}">${u ? `<a href="${esc(u)}">${label}</a>` : label}${i === 0 ? "<span>おすすめ</span>" : ""}</li>`;
  }).join("");
}

function emergencyLink() {
  return CFG.emergency ? `<p class="ain-small">休日・夜間の受診先は <a href="${esc(CFG.emergency)}">休日・夜間の受診案内</a> にまとめています。</p>` : "";
}

function mindBlock() {
  return `<div class="ain-mind"><p><strong>ひとりで抱え込まないでください。</strong>話を聞いてもらえる窓口があります。</p>
  <ul><li>よりそいホットライン <a href="tel:0120279338">0120-279-338</a>（24時間・無料）</li>
  <li>こころの健康相談統一ダイヤル <a href="tel:0570064556">0570-064-556</a>（お住まいの都道府県・政令市の窓口につながります。受付時間は地域によって違います）</li>
  <li>いのちの電話 <a href="tel:0120783556">0120-783-556</a>（毎日16時〜21時・無料）</li></ul>
  <p>今すぐ命の危険があるときは <strong>119番</strong> へ。</p></div>`;
}

function show(html) {
  root.querySelector(".ain-body").innerHTML = html;
  root.scrollIntoView({ block: "nearest", behavior: "smooth" });
}

function step1() {
  state = { who: null, item: null };
  show(`<p class="ain-q">どなたの症状ですか？</p>
  <div class="ain-btns"><button type="button" data-who="adult">大人（中学生以上）</button><button type="button" data-who="child">子ども（小学生以下）</button></div>`);
}

function step2() {
  const list = state.who === "child" ? CHILD : ADULT;
  show(`<p class="ain-q">いちばん困っている症状は？</p>
  <div class="ain-btns col">${list.map((x) => `<button type="button" data-item="${x.id}">${esc(x.q)}</button>`).join("")}</div>
  <button type="button" class="ain-back" data-go="1">← 戻る</button>`);
}

function step3() {
  const it = state.item;
  const checks = [...it.red.map((t) => ({ t, k: "call" })), ...it.warn.map((t) => ({ t, k: "ask" }))];
  if (!checks.length) return step4();
  show(`<p class="ain-q">次のうち、当てはまるものはありますか？</p>
  <div class="ain-checks">${checks.map((c, i) => `<label><input type="checkbox" data-k="${c.k}" value="${i}"> ${esc(c.t)}</label>`).join("")}</div>
  <div class="ain-btns"><button type="button" data-go="checked">次へ</button></div>
  <button type="button" class="ain-back" data-go="2">← 戻る</button>`);
}

// 都道府県ごとの救急相談窓口（emergency.php から pipeline/build_consult.py で作る）
const CONSULT = Array.isArray(CFG.consult) ? CFG.consult : [];
const PKEY = "aim_navi_pref";
let pref = "";
try { pref = localStorage.getItem(PKEY) || ""; } catch (e) {}
if (!CONSULT.some((c) => c.key === pref)) pref = "";
const telify = (t) => esc(t).replace(/(0\d{1,4}-\d{1,4}-\d{3,4}|0120-\d{2,3}-\d{3,4})/g, (m) => `<a href="tel:${m.replace(/-/g, "")}">${m}</a>`);

function consultHtml(isChild) {
  const sel = `<p class="ain-pref"><label>お住まいの都道府県：<select data-pref>
    <option value="">選んでください</option>${CONSULT.map((c) => `<option value="${esc(c.key)}"${c.key === pref ? " selected" : ""}>${esc(c.name)}</option>`).join("")}
  </select></label></p>`;
  const c = CONSULT.find((x) => x.key === pref);
  if (!c) {
    const body = isChild
      ? "子どもは <a href=\"tel:#8000\">#8000</a>（子ども医療電話相談）に電話すると、お住まいの都道府県の相談窓口につながります。受付時間は都道府県によって違います。"
      : "大人は <a href=\"tel:#7119\">#7119</a>（救急安心センター）で、救急車が必要か・どこにかかればよいかを相談できます。ただし #7119 をやっていない県・地域もあります。子どもは <a href=\"tel:#8000\">#8000</a> へ。";
    return `${sel}<p>${body}</p><p class="ain-small">都道府県を選ぶと、その県の窓口と受付時間を表示します。</p>
    <p class="ain-big"><a href="tel:${isChild ? "#8000" : "#7119"}">${isChild ? "#8000" : "#7119"}</a></p>`;
  }
  const num = isChild ? "#8000" : (c.a7119 ? "#7119" : "");
  const boxes = c.boxes.map((b) => `<p><strong>${esc(b.t)}</strong>（${b.n.map(esc).join("・")}）</p>${b.p.map((t) => `<p class="ain-small">${telify(t)}</p>`).join("")}`).join("");
  const no7119 = !isChild && !c.a7119 && !c.boxes.some((b) => b.p.some((t) => t.includes("#7119")))
    ? `<p><strong>${esc(c.name)}には、大人向けの #7119（救急相談）が県全体ではありません。</strong>迷うほど具合が悪いときは119番へ。受診先は下の案内で探せます。</p>` : "";
  const more = CFG.emergency ? `<p class="ain-small"><a href="${esc(CFG.emergency)}#er-${esc(c.key)}">${esc(c.name)}の休日・夜間の受診先を見る</a></p>` : "";
  return `${sel}${no7119}${boxes}${num ? `<p class="ain-big"><a href="tel:${num}">${num}</a></p>` : ""}${more}`;
}

let lastUrgent = null;
function urgent(kind) {
  lastUrgent = kind;
  const u = URGENT[kind];
  const isChild = state.who === "child";
  const inner = kind === "call"
    ? `<p>${u.body}</p><p class="ain-big"><a href="tel:119">119</a></p>`
    : consultHtml(isChild);
  show(`<div class="ain-urgent ${u.cls}"><p class="ain-ut">${u.title}</p>${inner}</div>
  ${state.item.mind ? mindBlock() : ""}
  ${emergencyLink()}
  <button type="button" class="ain-back" data-go="restart">最初からやり直す</button>`);
}

root.addEventListener("change", (e) => {
  const s = e.target.closest("select[data-pref]");
  if (!s) return;
  pref = s.value;
  try { localStorage.setItem(PKEY, pref); } catch (err) {}
  if (lastUrgent) urgent(lastUrgent);
});

function step4() {
  const it = state.item;
  show(`<p class="ain-q">いちばん近いのはどれですか？</p>
  <div class="ain-btns col">${it.choices.map((c, i) => `<button type="button" data-choice="${i}">${esc(c.a)}</button>`).join("")}</div>
  <button type="button" class="ain-back" data-go="2">← 戻る</button>`);
}

function result(c) {
  show(`<div class="ain-result"><p class="ain-q">受診先の目安</p>
  <ul class="ain-depts">${deptLinks(c.d)}</ul>
  <p>${esc(c.note)}</p>
  <p class="ain-small">科の名前を押すと、全国47都道府県でその科を診療している医療機関の一覧と地図が開きます。「いま診療時間内だけ」で今開いているところに絞れます。</p></div>
  ${state.item.mind ? mindBlock() : ""}
  ${emergencyLink()}
  <button type="button" class="ain-back" data-go="restart">最初からやり直す</button>`);
}

root.addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.who) { state.who = b.dataset.who; return step2(); }
  if (b.dataset.item) { state.item = (state.who === "child" ? CHILD : ADULT).find((x) => x.id === b.dataset.item); return step3(); }
  if (b.dataset.choice) return result(state.item.choices[+b.dataset.choice]);
  const g = b.dataset.go;
  if (g === "1" || g === "restart") return step1();
  if (g === "2") return step2();
  if (g === "checked") {
    const on = [...root.querySelectorAll(".ain-checks input:checked")].map((x) => x.dataset.k);
    if (on.includes("call")) return urgent("call");
    if (on.includes("ask")) return urgent("ask");
    return step4();
  }
});

step1();
})();
