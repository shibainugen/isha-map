<?php if (!defined('ABSPATH')) exit; ?>
<div class="aim" id="aim">
  <div class="aim-head">
    <div class="aim-controls aim-row-search">
      <button id="aim-locate" type="button">📍 現在地から</button>
      <form id="aim-search" class="aim-form" role="search">
        <input id="aim-q" aria-label="住所や地名" type="search" placeholder="住所・地名（例: 青葉台1丁目、原町田）" autocomplete="off">
        <button class="aim-ghost" type="submit">探す</button>
      </form>
    </div>
    <div class="aim-controls aim-row-filter">
      <select id="aim-dept" aria-label="診療科で絞り込む"><option value="">すべての診療科</option></select>
      <label class="aim-chip"><input id="aim-open" type="checkbox"> 🕒 いま診療時間内</label>
      <label class="aim-chip" title="小児科・小児皮膚科・小児耳鼻いんこう科など「小児」の付く科を届け出ている医療機関"><input id="aim-kids" type="checkbox"> 👶 子どもを診る</label>
    </div>
    <p class="aim-status" id="aim-status">医療機関のデータを読み込んでいます…</p>
    <p class="aim-opennote">🕒 は届け出の診療時間から出した目安です。臨時休診や受付終了は分かりません。受診前に電話で確かめてください。</p>
  </div>
  <div class="aim-body">
    <div id="aim-map" class="aim-map" aria-label="地図"></div>
    <ul id="aim-list" class="aim-list"></ul>
  </div>
  <div class="aim-foot">
    <p>出典: 厚生労働省「医療情報ネット（ナビイ）」オープンデータ（<span id="aim-asof">-</span>時点）を加工して作成。<a href="https://www.digital.go.jp/resources/open_data/public_data_license_v1.0" target="_blank" rel="noopener">公共データ利用規約（第1.0版）</a>に基づき利用しています。電話番号は各地方厚生局（北海道・東北・関東信越・東海北陸・近畿・中国四国・九州）の「保険医療機関・保険薬局の指定一覧」（<span id="aim-telasof">-</span>現在）によります。</p>
    <p>地図: <a href="https://maps.gsi.go.jp/development/ichiran.html" target="_blank" rel="noopener">地理院タイル</a>（国土地理院）。住所検索: 国土地理院 地名検索API。</p>
    <p>「診療時間内」は、2026年6月時点の届け出の診療時間から計算した目安です。臨時休診・休診日の変更・祝日の休みなどは反映されていません。受診前に必ず医療機関へご確認ください。</p>
  </div>
</div>
