<?php if (!defined('ABSPATH')) exit; ?>
<div class="ain" id="ain">
  <div class="ain-head">症状から何科にかかればいいか調べる<small>いくつかの質問に答えると、受診先の目安をご案内します（約30秒）</small></div>
  <div class="ain-body"><noscript>この機能を使うにはJavaScriptを有効にしてください。</noscript></div>
  <p class="ain-note">※ これは病気を診断するものではなく、受診する科の目安です。判断に迷うときや症状が重いときは、#7119（大人）・#8000（子ども）に相談するか、119番に電話してください。</p>
</div>
